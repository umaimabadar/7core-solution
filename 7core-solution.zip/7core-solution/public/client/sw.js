const CACHE = "7core-client-v1";
const SHELL = [
  "/client",
  "/client/index.html",
  "/client/style.css",
  "/client/app.js",
  "/client/manifest.webmanifest",
  "/assets/theme.css",
  "/fonts/fonts.css",
];
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith("/api/")) return;
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request)));
});
