(function () {
  var $ = function (s) {
    return document.querySelector(s);
  };
  var loginView = $("#loginView"),
    portalView = $("#portalView");
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function api(path, opts) {
    opts = opts || {};
    opts.credentials = "same-origin";
    return fetch(path, opts);
  }
  function render(data) {
    loginView.hidden = true;
    portalView.hidden = false;
    $("#welcome").textContent = "Welcome, " + data.client.name;
    $("#clientCompany").textContent = data.client.company || data.client.email;
    var projects = data.projects || [],
      tasks = data.tasks || [],
      invoices = data.invoices || [];
    $("#summary").innerHTML = [
      ["" + projects.length, "Active projects"],
      [
        "" +
          tasks.filter(function (x) {
            return x.status !== "DONE";
          }).length,
        "Open tasks",
      ],
      [
        "" +
          invoices.filter(function (x) {
            return x.status !== "PAID";
          }).length,
        "Outstanding invoices",
      ],
    ]
      .map(function (x) {
        return '<div class="cp-stat"><b>' + x[0] + "</b><span>" + x[1] + "</span></div>";
      })
      .join("");
    $("#projects").innerHTML = projects.length
      ? projects
          .map(function (p) {
            return (
              '<article class="cp-project"><h3>' +
              esc(p.name) +
              "</h3><small>" +
              esc(p.status.replace(/_/g, " ")) +
              " · " +
              esc(p.priority) +
              '</small><div class="cp-progress"><i style="width:' +
              Number(p.progress || 0) +
              '%"></i></div><small>' +
              Number(p.progress || 0) +
              "% complete" +
              (p.deadline ? " · Due " + esc(p.deadline) : "") +
              "</small></article>"
            );
          })
          .join("")
      : '<p class="cp-muted">No projects have been added yet.</p>';
    $("#tasks").innerHTML = tasks.length
      ? tasks
          .map(function (t) {
            return (
              '<div class="cp-list-row"><span>' +
              esc(t.title) +
              "</span><small>" +
              esc(t.status.replace(/_/g, " ")) +
              (t.due_date ? " · " + esc(t.due_date) : "") +
              "</small></div>"
            );
          })
          .join("")
      : '<p class="cp-muted">No tasks yet.</p>';
    $("#invoices").innerHTML = invoices.length
      ? invoices
          .map(function (i) {
            return (
              '<div class="cp-list-row"><span>' +
              esc(i.number) +
              " · " +
              esc(i.status) +
              "</span><strong>" +
              esc(i.currency) +
              " " +
              Number(i.total).toFixed(2) +
              "</strong></div>"
            );
          })
          .join("")
      : '<p class="cp-muted">No invoices yet.</p>';
  }
  function load() {
    api("/api/client/dashboard")
      .then(function (r) {
        if (r.status === 401) return;
        return r.json();
      })
      .then(function (d) {
        if (d) render(d);
      });
  }
  $("#loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    $("#loginError").textContent = "";
    api("/api/client/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: $("#email").value, password: $("#password").value }),
    })
      .then(function (r) {
        return r.json().then(function (d) {
          return { ok: r.ok, data: d };
        });
      })
      .then(function (x) {
        if (!x.ok) {
          $("#loginError").textContent = x.data.error || "Unable to sign in.";
          return;
        }
        load();
      });
  });
  $("#logout").addEventListener("click", function () {
    api("/api/client/auth/logout", { method: "POST" }).then(function () {
      location.reload();
    });
  });
  load();
})();
