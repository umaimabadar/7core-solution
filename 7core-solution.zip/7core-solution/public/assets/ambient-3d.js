(function () {
  "use strict";
  if (!window.THREE || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  var canvas = document.getElementById("ambient3d");
  if (!canvas) return;

  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas: canvas,
      alpha: true,
      antialias: true,
      powerPreference: "low-power",
    });
  } catch (err) {
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setClearColor(0x000000, 0);

  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
  camera.position.z = 6.4;
  var group = new THREE.Group();
  scene.add(group);

  var core = new THREE.Mesh(
    new THREE.IcosahedronGeometry(1.08, 2),
    new THREE.MeshBasicMaterial({
      color: 0x4c8dff,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
    }),
  );
  group.add(core);

  var halo = new THREE.Mesh(
    new THREE.SphereGeometry(1.48, 24, 24),
    new THREE.MeshBasicMaterial({
      color: 0x8b7cf6,
      transparent: true,
      opacity: 0.055,
      side: THREE.BackSide,
    }),
  );
  group.add(halo);

  var particles = new THREE.BufferGeometry();
  var positions = new Float32Array(120 * 3);
  for (var i = 0; i < 120; i++) {
    var radius = 2.2 + Math.random() * 2.4;
    var angle = Math.random() * Math.PI * 2;
    positions[i * 3] = Math.cos(angle) * radius;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 4.2;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 2.5;
  }
  particles.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  var stars = new THREE.Points(
    particles,
    new THREE.PointsMaterial({ color: 0x6ea6ff, size: 0.025, transparent: true, opacity: 0.48 }),
  );
  group.add(stars);

  var pointer = { x: 0, y: 0 };
  window.addEventListener(
    "pointermove",
    function (event) {
      pointer.x = (event.clientX / window.innerWidth - 0.5) * 0.18;
      pointer.y = (event.clientY / window.innerHeight - 0.5) * 0.12;
    },
    { passive: true },
  );

  function themeColors() {
    var light = document.documentElement.getAttribute("data-theme") === "light";
    core.material.color.setHex(light ? 0x2f6fed : 0x4c8dff);
    core.material.opacity = light ? 0.13 : 0.22;
    halo.material.color.setHex(light ? 0x7c6ae8 : 0x8b7cf6);
    halo.material.opacity = light ? 0.045 : 0.055;
    stars.material.opacity = light ? 0.25 : 0.48;
  }
  themeColors();
  new MutationObserver(themeColors).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["data-theme"],
  });

  function resize() {
    var width = window.innerWidth;
    var height = window.innerHeight;
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    group.position.x = width < 700 ? 1.2 : 2.3;
    group.position.y = width < 700 ? 1.1 : 0.4;
    group.scale.setScalar(width < 700 ? 0.72 : 1);
  }
  resize();
  window.addEventListener("resize", resize, { passive: true });

  function tick(time) {
    group.rotation.y = time * 0.00008 + pointer.x;
    group.rotation.x = Math.sin(time * 0.00012) * 0.08 + pointer.y;
    stars.rotation.y = -time * 0.000025;
    renderer.render(scene, camera);
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
