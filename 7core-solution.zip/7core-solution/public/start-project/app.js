(function () {
  var $ = function (s, r) {
    return (r || document).querySelector(s);
  };
  var $$ = function (s, r) {
    return [].slice.call((r || document).querySelectorAll(s));
  };

  /* ---------- theme (shared logic with the main site) ---------- */
  var doc = document.documentElement,
    tog = $("#themeTog"),
    meta = $("#themeColor"),
    KEY = "7core-theme";
  function applyTheme(mode, save) {
    doc.setAttribute("data-theme", mode);
    if (meta) meta.setAttribute("content", mode === "light" ? "#F6F8FC" : "#0A0E17");
    if (save) {
      try {
        localStorage.setItem(KEY, mode);
      } catch (e) {}
    }
  }
  if (tog)
    tog.addEventListener("click", function () {
      applyTheme(doc.getAttribute("data-theme") === "light" ? "dark" : "light", true);
    });

  /* ---------- WhatsApp / email config from the server, never hardcoded here ---------- */
  var WA_NUMBER = "923340231041",
    MAIL = "7coresolution.tech@gmail.com";
  fetch("/api/config")
    .then(function (r) {
      return r.ok ? r.json() : null;
    })
    .then(function (c) {
      if (!c) return;
      WA_NUMBER = c.whatsapp || WA_NUMBER;
      MAIL = c.email || MAIL;
      var hello = "Hi 7Core Solution, I found your website and would like to discuss a project.";
      var dw = $("#spDirectWa"),
        dm = $("#spDirectMail");
      if (dw) dw.href = "https://wa.me/" + WA_NUMBER + "?text=" + encodeURIComponent(hello);
      if (dm) dm.href = "mailto:" + MAIL + "?subject=" + encodeURIComponent("Project enquiry");
    })
    .catch(function () {});

  /* ---------- service / priority chip data ---------- */
  var SERVICES = [
    ["AI Development", "ai"],
    ["AI Automation", "auto"],
    ["AI Agents", "agents"],
    ["Website Development", "web"],
    ["Web Application", "webapp"],
    ["Mobile Application", "app"],
    ["UI/UX Design", "ux"],
    ["AI Animation", "video"],
    ["AI Video", "videoclip"],
    ["Digital Marketing", "mkt"],
    ["Cloud Solutions", "cloud"],
    ["Custom Software", "custom"],
    ["Other", "other"],
  ];
  var PRIOS = [
    "Speed",
    "Quality",
    "Budget",
    "Design",
    "AI",
    "Automation",
    "Performance",
    "Scalability",
    "Security",
    "User Experience",
  ];
  var STEP_LABELS = [
    "01 About you",
    "02 Services",
    "03 Project",
    "04 References",
    "05 Budget & timeline",
    "06 Review",
  ];

  function renderChips(host, list) {
    host.innerHTML = list
      .map(function (x) {
        var label = Array.isArray(x) ? x[0] : x,
          key = Array.isArray(x) ? x[1] : x;
        return (
          '<button type="button" class="sp-c" aria-pressed="false" data-k="' +
          key +
          '"><i></i><span>' +
          label +
          "</span></button>"
        );
      })
      .join("");
    host.addEventListener("click", function (e) {
      var b = e.target.closest(".sp-c");
      if (!b) return;
      b.setAttribute("aria-pressed", b.getAttribute("aria-pressed") === "true" ? "false" : "true");
      err("spServices", "");
    });
  }
  renderChips($("#spServices"), SERVICES);
  renderChips($("#spPriority"), PRIOS);
  $("#spDots").innerHTML = STEP_LABELS.map(function (s, i) {
    return '<span data-i="' + i + '">' + s + "</span>";
  }).join("");

  /* preselect services passed via ?services=ai,web from the main site */
  (function () {
    var q = new URLSearchParams(location.search).get("services");
    if (!q) return;
    var keys = q.split(",");
    $$("#spServices .sp-c").forEach(function (b) {
      if (keys.indexOf(b.dataset.k) > -1) b.setAttribute("aria-pressed", "true");
    });
  })();

  var picked = function (id) {
    return $$("#" + id + ' .sp-c[aria-pressed="true"]').map(function (b) {
      return b.querySelector("span").textContent;
    });
  };
  var val = function (id) {
    var el = $("#" + id);
    return el ? el.value.trim() : "";
  };
  function err(id, msg) {
    var s = document.querySelector('.sp-err[data-for="' + id + '"]'),
      el = $("#" + id);
    if (s) s.textContent = msg || "";
    if (el && el.classList) el.classList.toggle("bad", !!msg);
  }

  var step = 0,
    form = $("#spForm"),
    bar = $("#spBar"),
    dots = $("#spDots"),
    foot = $("#spFoot"),
    next = $("#spNext"),
    prev = $("#spPrev"),
    banner = $("#spBanner"),
    sending = false;
  var pickedFiles = [];
  var MAX_FILE_BYTES = 10 * 1024 * 1024;
  var ALLOWED_TYPES = [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/png",
    "image/jpeg",
    "image/webp",
  ];

  function show(n) {
    step = n;
    $$(".sp-step", form).forEach(function (s, i) {
      s.classList.toggle("on", i === n);
    });
    $$("#spDots span").forEach(function (d, i) {
      d.className = i === n ? "on" : i < n ? "done" : "";
    });
    bar.style.width = Math.round(((n + 1) / 7) * 100) + "%";
    var last = n === 6;
    dots.style.display = last ? "none" : "flex";
    foot.style.display = last ? "none" : "flex";
    prev.style.visibility = n === 0 ? "hidden" : "visible";
    next.textContent = n === 5 ? "Submit project" : "Continue \u2192";
    if (n === 5) review();
    window.scrollTo({ top: form.offsetTop - 90, behavior: "smooth" });
  }

  function valid(n) {
    var ok = true;
    if (n === 0) {
      ["spName", "spMail", "spWa"].forEach(function (i) {
        err(i, "");
      });
      if (val("spName").length < 2) {
        err("spName", "Please enter your name.");
        ok = false;
      }
      if (!/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(val("spMail"))) {
        err("spMail", "Please enter a valid email.");
        ok = false;
      }
      if (val("spWa").replace(/\D/g, "").length < 7) {
        err("spWa", "Please enter a reachable WhatsApp number.");
        ok = false;
      }
    }
    if (n === 1 && !picked("spServices").length) {
      err("spServices", "Pick at least one service.");
      ok = false;
    }
    if (n === 2) {
      err("spDesc", "");
      if (val("spDesc").length < 10) {
        err("spDesc", "A couple of sentences, please.");
        ok = false;
      }
    }
    if (!ok) form.scrollIntoView({ block: "start", behavior: "smooth" });
    return ok;
  }

  function esc(t) {
    return String(t || "").replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function collect() {
    return {
      name: val("spName"),
      company: val("spCo"),
      email: val("spMail"),
      whatsapp: val("spWa"),
      phone: val("spPhone"),
      country: val("spCountry"),
      city: val("spCity"),
      preferred_contact: val("spPref"),
      services: picked("spServices"),
      project_name: val("spPname"),
      description: val("spDesc"),
      goal: val("spGoal"),
      audience: val("spAud"),
      requirements: val("spReq"),
      references: val("spRefs")
        .split("\n")
        .map(function (s) {
          return s.trim();
        })
        .filter(Boolean),
      budget: val("spBudget"),
      timeline: val("spTime"),
      priorities: picked("spPriority"),
      additional: val("spExtra"),
    };
  }
  function review() {
    var d = collect();
    var rows = [
      ["Name", d.name],
      ["Company", d.company],
      ["Email", d.email],
      ["WhatsApp", d.whatsapp],
      ["Phone", d.phone],
      ["Location", [d.city, d.country].filter(Boolean).join(", ")],
      ["Contact via", d.preferred_contact],
      ["Services", d.services.join(" \u00b7 ")],
      ["Project name", d.project_name],
      ["Target users", d.audience],
      ["Description", d.description],
      ["Goal", d.goal],
      ["Requirements", d.requirements],
      ["References", d.references.join(", ")],
      [
        "Files",
        pickedFiles
          .map(function (f) {
            return f.name;
          })
          .join(", "),
      ],
      ["Budget", d.budget],
      ["Timeline", d.timeline],
      ["Priorities", d.priorities.join(" \u00b7 ")],
      ["Additional", d.additional],
    ];
    $("#spReview").innerHTML = rows
      .filter(function (r) {
        return r[1];
      })
      .map(function (r) {
        return '<div class="sp-row"><dt>' + r[0] + "</dt><dd>" + esc(r[1]) + "</dd></div>";
      })
      .join("");
  }

  /* ---------- file picker ---------- */
  $("#spFiles").addEventListener("change", function (e) {
    var incoming = [].slice.call(e.target.files);
    incoming.forEach(function (f) {
      if (pickedFiles.length >= 5) return;
      if (f.size > MAX_FILE_BYTES) {
        showBanner('"' + f.name + '" is larger than 10MB and was not added.');
        return;
      }
      if (ALLOWED_TYPES.indexOf(f.type) === -1) {
        showBanner('"' + f.name + '" is not a supported file type.');
        return;
      }
      pickedFiles.push(f);
    });
    e.target.value = "";
    renderFileList();
  });
  function showBanner(message) {
    banner.textContent = message;
    banner.classList.add("show");
  }
  function renderFileList() {
    var ul = $("#spFileList");
    ul.innerHTML = pickedFiles
      .map(function (f, i) {
        return (
          "<li><span>" +
          esc(f.name) +
          " (" +
          Math.round(f.size / 1024) +
          ' KB)</span><button type="button" data-i="' +
          i +
          '">Remove</button></li>'
        );
      })
      .join("");
    ul.querySelectorAll("button").forEach(function (b) {
      b.addEventListener("click", function () {
        pickedFiles.splice(Number(b.dataset.i), 1);
        renderFileList();
      });
    });
  }

  /* ---------- real submission ---------- */
  function submit() {
    if (sending) return;
    sending = true;
    next.disabled = true;
    next.textContent = "Sending\u2026";
    banner.classList.remove("show");
    var d = collect();
    var fd = new FormData();
    Object.keys(d).forEach(function (k) {
      var v = d[k];
      fd.append(k, Array.isArray(v) ? JSON.stringify(v) : v);
    });
    pickedFiles.forEach(function (f) {
      fd.append("files", f, f.name);
    });

    fetch("/api/leads", { method: "POST", body: fd })
      .then(function (r) {
        return r.json().then(function (j) {
          return { status: r.status, body: j };
        });
      })
      .then(function (res) {
        sending = false;
        next.disabled = false;
        next.textContent = "Submit project";
        if (res.status === 201) {
          $("#spRef").textContent = "Project ID: " + res.body.ref;
          var msg =
            "Project brief " +
            res.body.ref +
            "\n\nName: " +
            d.name +
            "\nEmail: " +
            d.email +
            "\nServices: " +
            d.services.join(", ") +
            "\n\n" +
            d.description;
          $("#spWaBtn").href = "https://wa.me/" + WA_NUMBER + "?text=" + encodeURIComponent(msg);
          $("#spMailBtn").href =
            "mailto:" +
            MAIL +
            "?subject=" +
            encodeURIComponent("Project brief " + res.body.ref + " \u2014 " + d.name) +
            "&body=" +
            encodeURIComponent(msg);
          show(6);
        } else if (res.status === 422 && res.body.fields) {
          Object.keys(res.body.fields).forEach(function (k) {
            var map = {
              name: "spName",
              email: "spMail",
              whatsapp: "spWa",
              services: "spServices",
              description: "spDesc",
            };
            if (map[k]) err(map[k], res.body.fields[k]);
          });
          banner.textContent = "Please check the highlighted fields.";
          banner.classList.add("show");
          show(0);
        } else {
          banner.textContent =
            res.body.error ||
            "Something went wrong. Please try again, or reach us directly on WhatsApp.";
          banner.classList.add("show");
        }
      })
      .catch(function () {
        sending = false;
        next.disabled = false;
        next.textContent = "Submit project";
        banner.textContent = "Could not reach the server. Check your connection and try again.";
        banner.classList.add("show");
      });
  }

  next.addEventListener("click", function () {
    if (step < 5) {
      if (!valid(step)) return;
      show(step + 1);
    } else submit();
  });
  prev.addEventListener("click", function () {
    if (step > 0) show(step - 1);
  });
  form.addEventListener("submit", function (e) {
    e.preventDefault();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && e.target.tagName !== "TEXTAREA" && step < 6) {
      e.preventDefault();
      next.click();
    }
  });
})();
