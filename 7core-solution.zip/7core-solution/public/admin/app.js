(function () {
  var $ = function (s, r) {
    return (r || document).querySelector(s);
  };
  var $$ = function (s, r) {
    return [].slice.call((r || document).querySelectorAll(s));
  };

  var STATUSES = ["NEW", "CONTACTED", "IN_DISCUSSION", "PROPOSAL_SENT", "WON", "LOST"];
  var STATUS_LABEL = {
    NEW: "New",
    CONTACTED: "Contacted",
    IN_DISCUSSION: "In discussion",
    PROPOSAL_SENT: "Proposal sent",
    WON: "Won",
    LOST: "Lost",
  };
  var SERVICES = [
    "AI Development",
    "AI Automation",
    "AI Agents",
    "Website Development",
    "Web Application",
    "Mobile Application",
    "UI/UX Design",
    "AI Animation",
    "AI Video",
    "Digital Marketing",
    "Cloud Solutions",
    "Custom Software",
    "Other",
  ];
  var CSRF_TOKEN = "";

  function fetchWithCsrf(url, options) {
    options = options || {};
    options.credentials = "same-origin";
    options.headers = Object.assign({}, options.headers || {});
    if (CSRF_TOKEN) {
      options.headers["X-CSRF-Token"] = CSRF_TOKEN;
    }
    return fetch(url, options);
  }

  /* ---------- theme ---------- */
  var doc = document.documentElement,
    tog = $("#themeTog"),
    KEY = "7core-theme";
  if (tog)
    tog.addEventListener("click", function () {
      var m = doc.getAttribute("data-theme") === "light" ? "dark" : "light";
      doc.setAttribute("data-theme", m);
      try {
        localStorage.setItem(KEY, m);
      } catch (e) {}
    });
  var side = $("#adSide"),
    menu = $("#adMenu");
  if (menu)
    menu.addEventListener("click", function () {
      var open = side.classList.toggle("open");
      menu.setAttribute("aria-expanded", open ? "true" : "false");
    });
  document.addEventListener("click", function (e) {
    if (
      side &&
      menu &&
      side.classList.contains("open") &&
      !side.contains(e.target) &&
      e.target !== menu
    ) {
      side.classList.remove("open");
      menu.setAttribute("aria-expanded", "false");
    }
  });

  /* ---------- auth guard: every page load checks the real session ---------- */
  function requireAuth() {
    return fetch("/api/auth/me", { credentials: "same-origin" })
      .then(function (r) {
        if (r.status === 401) {
          window.location.href = "/admin/login";
          return null;
        }
        return r.json();
      })
      .then(function (res) {
        if (!res || !res.admin) return null;
        return fetch("/api/auth/csrf", { credentials: "same-origin" }).then(function (r) {
          if (r.ok) {
            return r.json().then(function (j) {
              if (j.csrfToken) CSRF_TOKEN = j.csrfToken;
              return res;
            });
          }
          return res;
        });
      });
  }

  var toastEl = $("#toast");
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    setTimeout(function () {
      toastEl.classList.remove("show");
    }, 2200);
  }
  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function fmtDate(iso) {
    if (!iso) return "";
    var d = new Date(iso + (iso.endsWith("Z") ? "" : "Z"));
    return d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  }

  /* ---------- filter selects ---------- */
  $("#fStatus").innerHTML += STATUSES.map(function (s) {
    return '<option value="' + s + '">' + STATUS_LABEL[s] + "</option>";
  }).join("");
  $("#fService").innerHTML += SERVICES.map(function (s) {
    return '<option value="' + esc(s) + '">' + esc(s) + "</option>";
  }).join("");

  var current = { q: "", status: "", service: "", sort: "newest" };
  ["qSearch", "fStatus", "fService", "fSort"].forEach(function (id) {
    var el = $("#" + id);
    var evt = id === "qSearch" ? "input" : "change";
    var handler = function () {
      current.q = $("#qSearch").value.trim();
      current.status = $("#fStatus").value;
      current.service = $("#fService").value;
      current.sort = $("#fSort").value;
      loadLeads();
    };
    var t;
    el.addEventListener(
      evt,
      id === "qSearch"
        ? function () {
            clearTimeout(t);
            t = setTimeout(handler, 250);
          }
        : handler,
    );
  });

  /* ---------- stats ---------- */
  function loadStats() {
    fetch("/api/leads/stats", { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (s) {
        var cards = [["TOTAL", "Total leads", true]].concat(
          STATUSES.map(function (k) {
            return [k, STATUS_LABEL[k], false];
          }),
        );
        $("#adStats").innerHTML = cards
          .map(function (c) {
            return (
              '<div class="ad-stat' +
              (c[2] ? " accent" : "") +
              '"><b>' +
              (s[c[0]] || 0) +
              "</b><span>" +
              c[1] +
              "</span></div>"
            );
          })
          .join("");
      });
  }

  function loadTeam() {
    fetch("/api/admin/users", { credentials: "same-origin" })
      .then(function (r) {
        if (r.status === 403) {
          return null;
        }
        return r.json();
      })
      .then(function (res) {
        if (!res) return;
        $("#teamPanel").hidden = false;
        $("#teamRole").innerHTML = (res.roles || [])
          .map(function (role) {
            return '<option value="' + esc(role) + '">' + esc(role) + "</option>";
          })
          .join("");
        $("#teamList").innerHTML = (res.users || [])
          .map(function (user) {
            return (
              '<div class="ad-team-row" data-user-id="' +
              user.id +
              '"><div class="ad-team-user"><b>' +
              esc(user.email) +
              "</b><span>Added " +
              fmtDate(user.created_at) +
              "</span></div>" +
              '<div class="ad-team-actions"><select aria-label="Role for ' +
              esc(user.email) +
              '">' +
              (res.roles || [])
                .map(function (role) {
                  return (
                    '<option value="' +
                    esc(role) +
                    '" ' +
                    ((user.roles || []).indexOf(role) !== -1 ? "selected" : "") +
                    ">" +
                    esc(role) +
                    "</option>"
                  );
                })
                .join("") +
              "</select>" +
              '<button type="button" data-team-delete>Remove</button></div></div>'
            );
          })
          .join("");
      });
  }

  $("#teamForm").addEventListener("submit", function (e) {
    e.preventDefault();
    fetchWithCsrf("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: $("#teamEmail").value.trim(),
        password: $("#teamPassword").value,
        role: $("#teamRole").value,
      }),
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (res) {
        if (res.error) {
          toast(res.error);
          return;
        }
        $("#teamEmail").value = "";
        $("#teamPassword").value = "";
        toast("Team member added");
        loadTeam();
      });
  });

  $("#teamList").addEventListener("change", function (e) {
    if (e.target.tagName !== "SELECT") return;
    var row = e.target.closest("[data-user-id]");
    fetchWithCsrf("/api/admin/users/" + row.dataset.userId, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: e.target.value }),
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (res) {
        if (res.error) {
          toast(res.error);
          loadTeam();
        } else toast("Role updated");
      });
  });

  $("#teamList").addEventListener("click", function (e) {
    if (!e.target.matches("[data-team-delete]")) return;
    var row = e.target.closest("[data-user-id]");
    if (!window.confirm("Remove this team member?")) return;
    fetchWithCsrf("/api/admin/users/" + row.dataset.userId, { method: "DELETE" })
      .then(function (r) {
        return r.json();
      })
      .then(function (res) {
        if (res.error) {
          toast(res.error);
          return;
        }
        toast("Team member removed");
        loadTeam();
      });
  });

  /* ---------- lead list ---------- */
  function loadLeads() {
    var qs = new URLSearchParams();
    if (current.q) qs.set("q", current.q);
    if (current.status) qs.set("status", current.status);
    if (current.service) qs.set("service", current.service);
    if (current.sort) qs.set("sort", current.sort);
    fetch("/api/leads?" + qs.toString(), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (res) {
        var rows = res.leads || [];
        $("#leadsEmpty").style.display = rows.length ? "none" : "block";
        $("#leadsBody").innerHTML = rows
          .map(function (l) {
            return (
              '<tr class="row" data-id="' +
              l.id +
              '">' +
              '<td><span class="ad-name">' +
              esc(l.name) +
              "</span>" +
              (l.company
                ? '<br><span style="color:var(--muted);font-size:.78rem">' +
                  esc(l.company) +
                  "</span>"
                : "") +
              "</td>" +
              "<td>" +
              esc((l.services || []).slice(0, 2).join(" + ")) +
              (l.services && l.services.length > 2 ? " +" + (l.services.length - 2) : "") +
              "</td>" +
              "<td>" +
              esc(l.budget || "\u2014") +
              "</td>" +
              "<td>" +
              esc(l.timeline || "\u2014") +
              "</td>" +
              "<td>" +
              fmtDate(l.created_at) +
              "</td>" +
              '<td><span class="ad-badge ' +
              l.status +
              '">' +
              STATUS_LABEL[l.status] +
              "</span></td>" +
              "</tr>"
            );
          })
          .join("");
        $$("#leadsBody tr").forEach(function (tr) {
          tr.addEventListener("click", function () {
            openLead(tr.dataset.id);
          });
        });
      });
  }

  /* ---------- detail drawer ---------- */
  var drawer = $("#drawer"),
    sheet = $("#sheet");
  function closeDrawer() {
    drawer.classList.remove("on");
  }
  drawer.addEventListener("click", function (e) {
    if (e.target === drawer) closeDrawer();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeDrawer();
  });

  function kv(rows) {
    return (
      '<dl class="ad-kv">' +
      rows
        .filter(function (r) {
          return r[1];
        })
        .map(function (r) {
          return "<dt>" + r[0] + "</dt><dd>" + esc(r[1]) + "</dd>";
        })
        .join("") +
      "</dl>"
    );
  }

  function openLead(id) {
    fetch("/api/leads/" + id, { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (res) {
        renderLead(res.lead);
        drawer.classList.add("on");
      });
  }

  function renderLead(l) {
    var waHref =
      "https://wa.me/" +
      (l.whatsapp || "").replace(/\D/g, "") +
      "?text=" +
      encodeURIComponent(
        "Hi " + l.name + ", this is 7Core Solution regarding your project inquiry (" + l.ref + ").",
      );
    var mailHref =
      "mailto:" +
      l.email +
      "?subject=" +
      encodeURIComponent("Re: your 7Core project inquiry (" + l.ref + ")");
    var telHref = l.phone ? "tel:" + l.phone.replace(/\s+/g, "") : null;

    sheet.innerHTML =
      '<div class="ad-sheet-head"><div><h2>' +
      esc(l.name) +
      '</h2><div class="ref">' +
      esc(l.ref) +
      " \u00b7 " +
      fmtDate(l.created_at) +
      "</div></div>" +
      '<button class="ad-x" id="closeSheet" type="button">&#10005;</button></div>' +
      '<div class="ad-section"><h3>Status</h3><div class="ad-status-row" id="statusRow">' +
      STATUSES.map(function (s) {
        return (
          '<button type="button" data-s="' +
          s +
          '" class="' +
          (s === l.status ? "on" : "") +
          '">' +
          STATUS_LABEL[s] +
          "</button>"
        );
      }).join("") +
      "</div></div>" +
      '<div class="ad-section"><h3>Contact</h3>' +
      kv([
        ["Name", l.name],
        ["Company", l.company],
        ["Email", l.email],
        ["WhatsApp", l.whatsapp],
        ["Phone", l.phone],
        ["Location", [l.city, l.country].filter(Boolean).join(", ")],
        ["Prefers", l.preferred_contact],
      ]) +
      '<div class="ad-actions">' +
      '<a class="btn btn-sm btn-primary" href="' +
      waHref +
      '" target="_blank" rel="noopener">WhatsApp</a>' +
      '<a class="btn btn-sm btn-ghost" href="' +
      mailHref +
      '">Email</a>' +
      (telHref ? '<a class="btn btn-sm btn-ghost" href="' + telHref + '">Call</a>' : "") +
      "</div></div>" +
      '<div class="ad-section"><h3>Services</h3><div class="ad-chips">' +
      (l.services || [])
        .map(function (s) {
          return '<span class="ad-chip">' + esc(s) + "</span>";
        })
        .join("") +
      "</div></div>" +
      '<div class="ad-section"><h3>Project</h3>' +
      kv([
        ["Project", l.project_name],
        ["Goal", l.goal],
        ["Audience", l.target_audience],
      ]) +
      (l.project_description
        ? '<p style="font-size:.87rem;color:var(--t2);white-space:pre-wrap;margin-top:8px">' +
          esc(l.project_description) +
          "</p>"
        : "") +
      (l.requirements
        ? '<p style="font-size:.85rem;color:var(--muted);white-space:pre-wrap;margin-top:8px"><b style="color:var(--t2)">Requirements:</b> ' +
          esc(l.requirements) +
          "</p>"
        : "") +
      "</div>" +
      '<div class="ad-section"><h3>Budget &amp; timeline</h3>' +
      kv([
        ["Budget", l.budget],
        ["Timeline", l.timeline],
      ]) +
      "</div>" +
      (l.priorities && l.priorities.length
        ? '<div class="ad-section"><h3>Priorities</h3><div class="ad-chips">' +
          l.priorities
            .map(function (p) {
              return '<span class="ad-chip">' + esc(p) + "</span>";
            })
            .join("") +
          "</div></div>"
        : "") +
      (l.references && l.references.length
        ? '<div class="ad-section"><h3>References</h3><div class="ad-chips">' +
          l.references
            .map(function (u) {
              return (
                '<a class="ad-chip" href="' +
                esc(u) +
                '" target="_blank" rel="noopener">' +
                esc(u) +
                "</a>"
              );
            })
            .join("") +
          "</div></div>"
        : "") +
      '<div class="ad-section"><h3>Files</h3><ul class="ad-filelist" id="fileList">' +
      (l.files && l.files.length
        ? l.files
            .map(function (f) {
              return (
                "<li><span>" +
                esc(f.original_name) +
                ' <span style="color:var(--muted)">(' +
                Math.round((f.size || 0) / 1024) +
                " KB)</span></span>" +
                '<a href="/api/leads/' +
                l.id +
                "/files/" +
                f.id +
                '" target="_blank">Download</a></li>'
              );
            })
            .join("")
        : '<li style="color:var(--muted);border:0">No files uploaded.</li>') +
      "</ul></div>" +
      (l.additional_information
        ? '<div class="ad-section"><h3>Additional information</h3><p style="font-size:.87rem;color:var(--t2);white-space:pre-wrap">' +
          esc(l.additional_information) +
          "</p></div>"
        : "") +
      '<div class="ad-section"><h3>Internal notes <span style="color:var(--muted);text-transform:none;letter-spacing:0">&middot; private, never shown to the client</span></h3>' +
      '<div class="ad-notes" id="notesList">' +
      (l.notes && l.notes.length
        ? l.notes
            .map(function (n) {
              return (
                '<div class="ad-note">' +
                esc(n.note) +
                "<time>" +
                fmtDate(n.created_at) +
                "</time></div>"
              );
            })
            .join("")
        : '<div style="color:var(--muted);font-size:.85rem">No notes yet.</div>') +
      "</div>" +
      '<div class="ad-note-form"><textarea id="noteInput" placeholder="Add a note\u2026"></textarea>' +
      '<button class="btn btn-sm btn-primary" id="noteSave" type="button" style="align-self:flex-end">Save</button></div>' +
      "</div>";

    $("#closeSheet").addEventListener("click", closeDrawer);

    $$("#statusRow button").forEach(function (b) {
      b.addEventListener("click", function () {
        fetchWithCsrf("/api/leads/" + l.id, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: b.dataset.s }),
        })
          .then(function (r) {
            return r.json();
          })
          .then(function (res) {
            if (res.error) {
              toast(res.error);
              return;
            }
            if (res.lead) {
              toast("Status updated to " + STATUS_LABEL[res.lead.status]);
              renderLead(res.lead);
              loadStats();
              loadLeads();
            }
          });
      });
    });

    $("#noteSave").addEventListener("click", function () {
      var ta = $("#noteInput");
      var note = ta.value.trim();
      if (!note) return;
      fetchWithCsrf("/api/leads/" + l.id + "/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note: note }),
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (res) {
          if (res.error) {
            toast(res.error);
            return;
          }
          if (res.notes) {
            l.notes = res.notes;
            ta.value = "";
            toast("Note added");
            renderLead(l);
          }
        });
    });
  }

  /* ---------- logout ---------- */
  $("#logoutBtn").addEventListener("click", function () {
    fetchWithCsrf("/api/auth/logout", { method: "POST" }).then(function () {
      window.location.href = "/admin/login";
    });
  });

  /* ---------- boot ---------- */
  requireAuth().then(function (res) {
    if (!res) return;
    $("#whoEmail").textContent = res.admin.email;
    loadStats();
    loadLeads();
    loadTeam();
    setInterval(loadStats, 60000);
  });
})();
