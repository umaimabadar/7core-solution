#!/usr/bin/env node
// server.js — entry point. Plain Node http server: serves the static public/
// site and mounts the API under /api. No Express (not installable without
// network access here), but the routing is deliberately Express-shaped so
// swapping in Express later, if you have network access, is a small diff.
"use strict";
require("./server/load-env")();
const http = require("node:http");
const url = require("node:url");
const path = require("node:path");
const fs = require("node:fs");
const routes = require("./server/routes");
const { initDb } = require("./server/db");

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, "public");
const SITE_ORIGIN = (process.env.SITE_ORIGIN || `http://localhost:${PORT}`).replace(/\/$/, "");

function applySecurityHeaders(res, opts = {}) {
  const isHtml = !!opts.isHtml;
  const allowSameOriginFrame = !!opts.allowSameOriginFrame;
  const csp = [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    allowSameOriginFrame ? "frame-ancestors 'self'" : "frame-ancestors 'none'",
    "img-src 'self' data: https:",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com https://fonts.googleapis.com",
    "connect-src 'self' https:",
    "form-action 'self' https:",
    "media-src 'self'",
    "upgrade-insecure-requests",
  ].join("; ");

  res.setHeader("Content-Security-Policy", csp);
  res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", allowSameOriginFrame ? "SAMEORIGIN" : "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  if (isHtml) {
    res.setHeader("Cache-Control", "no-cache");
  }
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".mp4": "video/mp4",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
};

function serveStatic(req, res, pathname) {
  const videoAsset = pathname.startsWith("/animated-video/");
  const demoPage = {
    "/demos/meridian-clinic": path.join(__dirname, "meridian-clinic", "meridian-clinic.html"),
    "/demos/7coresolutions-restaurant": path.join(
      __dirname,
      "7coresolutions-restaurant",
      "7coresolutions-restaurant.html",
    ),
  }[pathname];
  const assetRoot = videoAsset ? path.join(__dirname, "animated-video") : PUBLIC_DIR;
  let rel = videoAsset
    ? pathname.slice("/animated-video".length)
    : pathname === "/"
      ? "/index.html"
      : pathname;
  if (rel === "/start-project") rel = "/start-project/index.html";
  if (rel === "/admin") rel = "/admin/index.html";
  if (rel === "/admin/login") rel = "/admin/login.html";
  if (rel === "/client") rel = "/client/index.html";
  if (rel === "/privacy-policy") rel = "/privacy-policy/index.html";
  if (rel === "/terms-and-conditions") rel = "/terms-and-conditions/index.html";

  const full = demoPage || path.resolve(assetRoot, `.${rel}`);
  if (!demoPage && !full.startsWith(`${assetRoot}${path.sep}`)) {
    res.writeHead(400);
    return res.end("Bad request");
  }

  fs.stat(full, (err, st) => {
    if (err || !st.isFile()) {
      // SPA-style fallback for the two app shells only
      if (pathname.startsWith("/admin")) return serveStatic(req, res, "/admin/index.html");
      applySecurityHeaders(res, { isHtml: true });
      res.writeHead(404, { "Content-Type": "text/plain" });
      return res.end("Not found");
    }
    const ext = path.extname(full).toLowerCase();
    const isHtml = ext === ".html";
    applySecurityHeaders(res, { isHtml, allowSameOriginFrame: !!demoPage });
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": isHtml ? "no-cache" : "public, max-age=3600",
    });
    fs.createReadStream(full).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = decodeURIComponent(parsed.pathname);
  const method = req.method;

  try {
    applySecurityHeaders(res, { isHtml: false });

    // ---------- API ----------
    if (pathname === "/api/leads" && method === "POST") return await routes.createLead(req, res);
    if (pathname === "/api/leads" && method === "GET")
      return await routes.listLeads(req, res, parsed.query);
    if (pathname === "/api/leads/stats" && method === "GET") return await routes.stats(req, res);

    let m;
    if ((m = pathname.match(/^\/api\/leads\/(\d+)$/)) && method === "GET")
      return await routes.getLead(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/leads\/(\d+)$/)) && method === "PATCH")
      return await routes.patchLead(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/leads\/(\d+)$/)) && method === "DELETE")
      return await routes.deleteLead(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/leads\/(\d+)\/notes$/)) && method === "POST")
      return await routes.addNote(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/leads\/(\d+)\/files$/)) && method === "POST")
      return await routes.addFilesToLead(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/leads\/(\d+)\/files\/(\d+)$/)) && method === "GET")
      return await routes.downloadFile(req, res, { id: m[1], fileId: m[2] });

    if (pathname === "/api/auth/login" && method === "POST") return await routes.login(req, res);
    if (pathname === "/api/auth/csrf" && method === "GET") return await routes.csrf(req, res);
    if (pathname === "/api/auth/logout" && method === "POST") return await routes.logout(req, res);
    if (pathname === "/api/auth/me" && method === "GET") return await routes.me(req, res);
    if (pathname === "/api/client/auth/login" && method === "POST")
      return await routes.clientLogin(req, res);
    if (pathname === "/api/client/auth/logout" && method === "POST")
      return await routes.clientLogout(req, res);
    if (pathname === "/api/client/me" && method === "GET") return await routes.clientMe(req, res);
    if (pathname === "/api/client/dashboard" && method === "GET")
      return await routes.clientDashboard(req, res);
    if (pathname === "/api/v1/auth/login" && method === "POST")
      return await routes.mobileLogin(req, res);
    if (pathname === "/api/v1/auth/refresh" && method === "POST")
      return await routes.mobileRefresh(req, res);
    if (pathname === "/api/v1/auth/logout" && method === "POST")
      return await routes.mobileLogout(req, res);
    if (pathname === "/api/v1/me" && method === "GET") return await routes.mobileMe(req, res);
    if (pathname === "/api/v1/dashboard" && method === "GET")
      return await routes.mobileDashboard(req, res);

    if (pathname === "/api/admin/users" && method === "GET") return await routes.listAdminUsers(req, res);
    if (pathname === "/api/admin/users" && method === "POST")
      return await routes.createAdminUser(req, res);
    if ((m = pathname.match(/^\/api\/admin\/users\/(\d+)$/)) && method === "PATCH")
      return await routes.updateAdminUser(req, res, { id: m[1] });
    if ((m = pathname.match(/^\/api\/admin\/users\/(\d+)$/)) && method === "DELETE")
      return await routes.deleteAdminUser(req, res, { id: m[1] });
    if (pathname === "/api/admin/audit-logs" && method === "GET")
      return await routes.listAuditLogs(req, res, parsed.query);
    if (pathname === "/api/admin/clients" && method === "GET") return await routes.listClients(req, res);
    if (pathname === "/api/admin/clients" && method === "POST")
      return await routes.createClient(req, res);
    if (pathname === "/api/admin/projects" && method === "POST")
      return await routes.createProject(req, res);
    if ((m = pathname.match(/^\/api\/admin\/tasks\/(\d+)$/)) && method === "PATCH")
      return await routes.updateTask(req, res, { id: m[1] });

    if (pathname === "/api/config" && method === "GET") {
      // safe, public, non-secret configuration the frontend needs
      return await routes.sendJSON(res, 200, {
        whatsapp: process.env.WHATSAPP_NUMBER || "",
        email: process.env.CONTACT_EMAIL || "",
        phone: process.env.CONTACT_PHONE || "",
      });
    }

    if (pathname === "/api/animation-videos" && method === "GET") {
      const files = await fs.promises.readdir(path.join(__dirname, "animated-video"), {
        withFileTypes: true,
      });
      const videos = files
        .filter((file) => file.isFile() && path.extname(file.name).toLowerCase() === ".mp4")
        .map((file) => file.name)
        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
      return await routes.sendJSON(res, 200, videos);
    }

    if (pathname === "/healthz" && method === "GET") {
      return await routes.sendJSON(res, 200, { ok: true, service: "7core-solution" });
    }
    if (pathname === "/robots.txt" && method === "GET") {
      applySecurityHeaders(res, { isHtml: false });
      res.writeHead(200, {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "public, max-age=3600",
      });
      return res.end(
        `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\nSitemap: ${SITE_ORIGIN}/sitemap.xml\n`,
      );
    }
    if (pathname === "/sitemap.xml" && method === "GET") {
      applySecurityHeaders(res, { isHtml: false });
      res.writeHead(200, {
        "Content-Type": "application/xml; charset=utf-8",
        "Cache-Control": "public, max-age=3600",
      });
      return res.end(
        `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${SITE_ORIGIN}/</loc></url><url><loc>${SITE_ORIGIN}/start-project</loc></url><url><loc>${SITE_ORIGIN}/privacy-policy</loc></url><url><loc>${SITE_ORIGIN}/terms-and-conditions</loc></url></urlset>`,
      );
    }

    if (pathname.startsWith("/api/")) {
      return await routes.sendJSON(res, 404, { error: "No such endpoint" });
    }

    // ---------- static site ----------
    if (method === "GET" || method === "HEAD") return serveStatic(req, res, pathname);
    res.writeHead(405, { "Content-Type": "text/plain" });
    res.end("Method not allowed");
  } catch (err) {
    const status = err.status || 500;
    console.error("[7Core] request error:", err);
    if (!res.headersSent) {
      routes.sendJSON(res, status, {
        error: status === 500 ? "Something went wrong. Please try again." : err.message,
      });
    }
  }
});

module.exports = server;

initDb()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`7Core Solution running at http://localhost:${PORT}`);
      console.log(`  Public site       http://localhost:${PORT}/`);
      console.log(`  Start a project   http://localhost:${PORT}/start-project`);
      console.log(`  Admin login       http://localhost:${PORT}/admin/login`);
    });
  })
  .catch((err) => {
    console.error("[7Core] MySQL initialization failed:", err);
    process.exit(1);
  });
