#!/usr/bin/env node
// scripts/create-admin.js
// Creates (or resets the password of) the first admin account.
// Reads ADMIN_EMAIL / ADMIN_PASSWORD from .env — nothing is ever hardcoded
// into source. Run with: npm run create-admin
"use strict";
require("../server/load-env")();
const readline = require("node:readline");
const { initDb, closeDb, get, run } = require("../server/db");
const { hashPassword } = require("../server/auth");

function ask(question, hidden) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    if (hidden) {
      // minimal password masking
      rl._writeToOutput = function (s) {
        if (s.includes("\n")) rl.output.write(s);
      };
    }
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer);
    });
  });
}

async function main() {
  await initDb();
  let email = process.env.ADMIN_EMAIL;
  let password = process.env.ADMIN_PASSWORD;

  if (!email) email = (await ask("Admin email: ")).trim();
  if (!password) password = (await ask("Admin password (min 10 chars): ", true)).trim();
  console.log("");

  if (!/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(email)) {
    console.error("That does not look like a valid email address.");
    process.exit(1);
  }
  if (!password || password.length < 10) {
    console.error("Password must be at least 10 characters.");
    process.exit(1);
  }
  if (
    password === "admin" ||
    password === "password" ||
    password === "change_this_before_first_run"
  ) {
    console.error("Please choose a real password, not the placeholder.");
    process.exit(1);
  }

  const hash = hashPassword(password);
  const existing = await get("SELECT id FROM admins WHERE email = ?", [email]);
  if (existing) {
    await run(`UPDATE admins SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [
      hash,
      existing.id,
    ]);
    console.log(`Password updated for existing admin: ${email}`);
  } else {
    await run("INSERT INTO admins (email, password_hash) VALUES (?,?)", [email, hash]);
    console.log(`Admin account created: ${email}`);
  }
  console.log("You can now log in at /admin/login");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
}).finally(async () => {
  try {
    await closeDb();
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  }
});
