#!/usr/bin/env node
"use strict";
require("../server/load-env")();
const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const {
  initDb,
  seedDb,
  closeDb,
  get,
  tableNames,
  normalizeDateTimeValue,
  withTransaction,
} = require("../server/db");

const BATCH_SIZE = 250;
const MIGRATION_ID = "sqlite-to-mysql-import";
const datetimeColumns = {
  admins: ["created_at", "updated_at"],
  roles: ["created_at"],
  permissions: ["created_at"],
  admin_roles: ["created_at"],
  role_permissions: ["created_at"],
  sessions: ["created_at", "expires_at"],
  audit_logs: ["created_at"],
  leads: ["created_at", "updated_at"],
  lead_files: ["created_at"],
  lead_notes: ["created_at", "updated_at"],
  clients: ["created_at", "updated_at"],
  client_accounts: ["created_at", "updated_at"],
  client_sessions: ["created_at", "expires_at"],
  mobile_sessions: [
    "access_expires_at",
    "refresh_expires_at",
    "created_at",
    "revoked_at",
  ],
  projects: ["created_at", "updated_at"],
  milestones: ["created_at", "updated_at"],
  tasks: ["created_at", "updated_at"],
  proposals: ["created_at", "updated_at"],
  invoices: ["created_at", "updated_at"],
  payments: ["created_at"],
  schema_migrations: ["applied_at"],
};

async function main() {
  const sqlitePath = path.resolve(process.env.SQLITE_PATH || "./data/database.sqlite");
  if (!fs.existsSync(sqlitePath)) throw new Error(`SQLite source file not found: ${sqlitePath}`);

  await initDb({ seed: false });
  const completed = await get("SELECT id FROM schema_migrations WHERE id = ?", [MIGRATION_ID]);
  if (completed) {
    console.log("SQLite data has already been migrated into this MySQL database.");
    await seedDb();
    return;
  }

  const source = new DatabaseSync(sqlitePath, { readOnly: true });
  try {
    const sourceTables = new Set(
      source
        .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
        .all()
        .map((row) => row.name),
    );
    const missing = tableNames.filter((name) => !sourceTables.has(name));
    if (missing.length) {
      console.warn(`Source is missing tables (skipping): ${missing.join(", ")}`);
    }

    const occupied = [];
    for (const table of tableNames) {
      const row = await get(`SELECT COUNT(*) AS count FROM \`${table}\``);
      if (Number(row.count) > 0) occupied.push(table);
    }
    if (occupied.length) {
      throw new Error(
        `The target MySQL database is not empty (${occupied.join(", ")}). Use a new, empty database.`,
      );
    }

    const copied = {};
    await withTransaction(async (connection) => {
      for (const table of tableNames) {
        if (!sourceTables.has(table)) continue;
        let offset = 0;
        copied[table] = 0;
        while (true) {
          const rows = source
            .prepare(`SELECT * FROM \`${table}\` LIMIT ? OFFSET ?`)
            .all(BATCH_SIZE, offset);
          if (!rows.length) break;
          const columns = Object.keys(rows[0]);
          const placeholders = `(${columns.map(() => "?").join(",")})`;
          const sql = `INSERT INTO \`${table}\` (${columns.map((column) => `\`${column}\``).join(",")}) VALUES ${rows.map(() => placeholders).join(",")}`;
          const dateColumns = new Set(datetimeColumns[table] || []);
          const values = rows.flatMap((row) =>
            columns.map((column) =>
              dateColumns.has(column) ? normalizeDateTimeValue(row[column]) : row[column],
            ),
          );
          await connection.execute(sql, values);
          copied[table] += rows.length;
          offset += rows.length;
        }
      }
      await connection.execute("INSERT INTO schema_migrations (id) VALUES (?)", [MIGRATION_ID]);
    });

    await seedDb();
    const total = Object.values(copied).reduce((sum, count) => sum + count, 0);
    console.log(`Migrated ${total} rows from SQLite into MySQL.`);
    for (const [table, count] of Object.entries(copied)) {
      if (count) console.log(`  ${table}: ${count}`);
    }
    console.log("The SQLite file and uploaded files were left unchanged.");
  } finally {
    source.close();
  }
}

main()
  .catch((err) => {
    console.error("SQLite-to-MySQL migration failed:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    try {
      await closeDb();
    } catch (err) {
      console.error("Failed to close the MySQL connection pool:", err);
      process.exitCode = 1;
    }
  });
