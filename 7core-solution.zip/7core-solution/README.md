# 7Core Solution — full-stack platform

Public 3D website, a client project-intake system, and a private admin CRM,
all served by one small Node.js application.

## What this actually is

The server uses Node's built-in `node:http` and `node:crypto` modules with
MySQL for persistent data. The API uses the `mysql2` package and asynchronous
queries. A few things (the multipart parser and SMTP client) remain
hand-written.

## Requirements

- Node.js **18 or newer**. Check with `node -v`.
- A MySQL 8.0+ server and a database/user configured for this application.
- Run `npm install` to install the MySQL driver.

## Quick start

```bash
cd 7core-solution
npm install
cp .env.example .env
# create the MYSQL_DATABASE and grant MYSQL_USER access to it
# edit .env with your MySQL connection settings and admin credentials

npm run create-admin   # creates the first admin account (hashed password)
npm start               # or: npm run dev  (auto-restarts on file changes)
```

Open:
- **Public site** — http://localhost:3000/
- **Start a project** — http://localhost:3000/start-project
- **Admin login** — http://localhost:3000/admin/login

## Design system

Blue (`--accent`) is the dominant technology color — primary buttons, links,
active nav states, and interactive highlights. Violet (`--secondary`) is
used sparingly as the AI/complementary accent — gradient transitions,
secondary highlights, decorative glow. Both themes share one token file
(`public/assets/theme.css`), which the public site, `/start-project`, and
`/admin` all load, so a palette change in one place updates everywhere:

| Token | Dark | Light |
|---|---|---|
| `--accent` (blue, primary) | `#4C8DFF` | `#2F6FED` |
| `--secondary` (violet, accent) | `#8B7CF6` | `#7C6AE8` |
| `--bg` | `#0A0E17` | `#F6F8FC` |
| `--panel` | `#0F1420` | `#FFFFFF` |
| `--text` / `--t1` | `#F1F5FB` | `#0F1522` |
| `--muted` | `#7C8698` | `#667085` |
| `--success` / `--warning` / `--error` | `#34D399` / `#F5A524` / `#F1735E` | `#16A34A` / `#D97706` / `#DC4B39` |

The 3D scene repaints itself on theme switch (`paint3D()` in `index.html`):
material colors are classified by luminance and red/green channel balance
so blue-leaning and violet-leaning parts of the model land on the right
side of the light-mode palette rather than all collapsing to one flat tone.



This project's `public/` folder does not include your original
`vendor/three.min.js` or the local Sora/Manrope font files — I don't have
them and had no network access to fetch a copy. Two options:

1. **Copy your existing files in** (recommended): drop your original
   `vendor/three.min.js` into `public/vendor/`, and if you have the original
   local font files, replace `public/fonts/fonts.css` with your original
   `@font-face` rules. The 3D hero, scroll scene and everything else picks
   them up automatically — nothing else needs to change.
2. **Do nothing**: `public/fonts/fonts.css` currently loads Sora + Manrope
   from Google Fonts, so type looks right immediately. Three.js has no such
   fallback — without `vendor/three.min.js` the site shows a small on-page
   notice and falls back to a flat circle instead of crashing.

## Project structure

```
7core-solution/
├── server.js                  entry point — plain http server + router
├── server/
│   ├── db.js                  MySQL schema + asynchronous query helpers
│   ├── auth.js                 password hashing, sessions, cookies
│   ├── routes.js               every API handler
│   ├── multipart.js            hand-written multipart/form-data parser
│   ├── files.js                upload validation + secure storage
│   ├── notify.js                optional lead-notification email (raw SMTP)
│   └── load-env.js             tiny .env loader
├── scripts/
│   ├── create-admin.js          first-run admin account creation
│   └── migrate-sqlite-to-mysql.js one-time SQLite data import
├── public/                     everything served to browsers
│   ├── index.html               the public 3D site
│   ├── start-project/           client project-intake page (/start-project)
│   ├── admin/                   login + dashboard (/admin, /admin/login)
│   ├── assets/theme.css         shared design tokens (dark/light)
│   ├── fonts/, vendor/          fonts + three.js (see above)
├── uploads/                     client-uploaded files, outside public/
├── .env.example
└── .gitignore
```

## Environment variables

See `.env.example` for the full list with comments. The important ones:

| Variable | Purpose |
|---|---|
| `SESSION_SECRET` | Not currently used to sign anything cryptographically (sessions are opaque random IDs stored server-side), but kept for forward-compatibility and to satisfy the "long random secret in env" requirement. Generate one with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`. |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Read only by `npm run create-admin`, once, to create the first account. Not read by the running server. Delete them from `.env` after first run if you like. |
| `MYSQL_HOST` | MySQL server hostname. Defaults to `127.0.0.1`. |
| `MYSQL_PORT` | MySQL server port. Defaults to `3306`. |
| `MYSQL_USER` / `MYSQL_PASSWORD` | Credentials for the MySQL application user. |
| `MYSQL_DATABASE` | Existing MySQL database/schema. Defaults to `7core_solution`; the server creates its tables but not the database itself. |
| `UPLOAD_DIR` | Where uploaded files are stored, outside `public/`. |
| `WHATSAPP_NUMBER` / `CONTACT_EMAIL` / `CONTACT_PHONE` | Used everywhere WhatsApp, email, and phone contact details appear. Change these values and the public contact surfaces update after restarting the server. |
| `SMTP_*` / `NOTIFY_EMAIL` | Optional. Leave blank and the app works exactly the same, just without email notifications on new leads. |

**Never commit `.env`.** `.gitignore` already excludes it.

For example, a MySQL administrator can create the application database and
user with:

```sql
CREATE DATABASE 7core_solution CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER '7core'@'%' IDENTIFIED BY '<choose-a-strong-password>';
GRANT ALL PRIVILEGES ON 7core_solution.* TO '7core'@'%';
```

Use a host-specific MySQL account instead of `'%'` when the app and database
run on the same host.

## Creating the first admin account

```bash
npm run create-admin
```

If `ADMIN_EMAIL`/`ADMIN_PASSWORD` are set in `.env`, it uses those. Otherwise
it prompts you interactively. The password is hashed with scrypt before
anything touches the database — nothing is ever stored, logged, or
hardcoded in plaintext. Run the same command again later to reset the
password for an existing email.

## Migrating existing SQLite data

Set `SQLITE_PATH` to the existing SQLite file if it is not
`./data/database.sqlite`. Configure `.env` with a **new, empty** MySQL
database and run:

```bash
npm install
npm run migrate-sqlite
```

The migration copies all application tables and IDs in foreign-key order,
then initializes MySQL's authorization seed data. It does not delete or
modify the SQLite file or uploaded files. Stop the old application before
migrating, and keep a separate backup until you verify the migrated data.
The migration requires Node.js 22.13 or newer for its read-only SQLite
reader and refuses to run twice against the same target database.

## How the client → admin flow actually works

1. A visitor fills out `/start-project` (or clicks "Start your project" /
   a per-service "Need this service?" link, which pre-selects that service).
2. On submit, the browser sends a real `multipart/form-data` request to
   `POST /api/leads` — text fields plus up to 5 files.
3. The server validates every field server-side (not just in the browser),
   validates each file's type and size, generates a random filename, and
   writes it under `uploads/<lead-ref>/`.
4. A row is written to `leads`, plus rows in `lead_services`,
   `lead_priorities`, `lead_references`, and `lead_files`.
5. If SMTP is configured, a plain-text notification email fires (and if it
   fails, the lead is still saved — notification is best-effort, never a
   dependency for saving data).
6. The client sees a success screen with a real reference ID like
   `7C-2026-A1B2C3`, and WhatsApp/email buttons pre-filled with a summary.
7. Logging into `/admin` shows that lead immediately — same database, same
   process, no sync step.

## API reference

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/leads` | public | Submit a project brief (JSON or multipart) |
| GET | `/api/leads` | admin | List leads. Query: `q`, `status`, `service`, `budget`, `timeline`, `sort` |
| GET | `/api/leads/stats` | admin | Counts by status |
| GET | `/api/leads/:id` | admin | Full lead detail, including services/priorities/references/files/notes |
| PATCH | `/api/leads/:id` | admin | Update `{ status }` |
| DELETE | `/api/leads/:id` | admin | Delete a lead, related rows, and its stored upload directory |
| POST | `/api/leads/:id/notes` | admin | Add an internal note `{ note }` |
| POST | `/api/leads/:id/files` | admin | Attach additional files to an existing lead |
| GET | `/api/leads/:id/files/:fileId` | admin | Download a stored file |
| POST | `/api/auth/login` | public | `{ email, password }` → sets session cookie |
| POST | `/api/auth/logout` | admin | Clears the session |
| GET | `/api/auth/csrf` | admin | Rotates and returns the CSRF token used for mutations |
| GET | `/api/auth/me` | admin | Returns the signed-in admin, roles, and permissions, or 401 |
| GET | `/api/admin/users` | `MANAGE_USERS` | List admin accounts and available roles |
| POST | `/api/admin/users` | `MANAGE_USERS` + CSRF | Create an admin account with a role |
| PATCH | `/api/admin/users/:id` | `MANAGE_USERS` + CSRF | Change a role or reset an admin password |
| DELETE | `/api/admin/users/:id` | `MANAGE_USERS` + CSRF | Remove an admin account |
| GET | `/api/admin/audit-logs` | `MANAGE_USERS` | Read administrative audit events |
| GET | `/api/admin/clients` | `CLIENTS_VIEW` | List clients and project counts |
| POST | `/api/admin/clients` | `CLIENTS_MANAGE` + CSRF | Create a client and client login account |
| POST | `/api/admin/projects` | `PROJECTS_MANAGE` + CSRF | Create a project for a client |
| PATCH | `/api/admin/tasks/:id` | `PROJECTS_MANAGE` + CSRF | Update task status, priority, or due date |
| POST | `/api/client/auth/login` | public | Sign a client into the client portal |
| POST | `/api/client/auth/logout` | client | End a client session |
| GET | `/api/client/me` | client | Return the signed-in client profile |
| GET | `/api/client/dashboard` | client | Return only the client's projects, tasks, milestones, and invoices |
| POST | `/api/v1/auth/login` | public | Mobile login; returns short-lived bearer and refresh tokens |
| POST | `/api/v1/auth/refresh` | public | Rotate a refresh token and issue a new token pair |
| POST | `/api/v1/auth/logout` | mobile bearer | Revoke the current mobile session |
| GET | `/api/v1/me` | mobile bearer | Return the authenticated mobile client |
| GET | `/api/v1/dashboard` | mobile bearer | Return ownership-scoped mobile dashboard data |
| GET | `/api/config` | public | Returns the configured WhatsApp number, contact email, and contact phone |
| GET | `/healthz` | public | Lightweight application health check |

Every "admin" route returns `401 {"error":"Not authenticated"}` without a
valid session cookie — verified directly, not assumed. Authenticated mutation
requests also require the CSRF token in the `X-CSRF-Token` header.

### Roles and permissions

The database now includes an idempotent RBAC foundation:

- `SUPER_ADMIN` — all current permissions
- `ADMIN` — operational access to the current admin CRM
- `SALES` — lead viewing, updates, notes, file viewing, and analytics

The admin dashboard includes a Team access panel for users with
`MANAGE_USERS`. The server prevents self-deletion, self-demotion, and removal
of the last `SUPER_ADMIN`.

Administrative logins, failed logins, logout, account changes, lead status
changes, lead deletion, notes, uploads, and downloads are recorded in
`audit_logs`. Passwords, session tokens, and note contents are never logged.

The client foundation uses separate `client_accounts`, `client_sessions`, and
ownership-linked domain tables. Client dashboard queries always scope projects,
tasks, milestones, and invoices through the authenticated client's `client_id`;
the client portal cannot access `/admin` records or another client's data.

The commercial tables (`proposals`, `invoices`, and `payments`) are storage
foundations only. No payment provider or legally binding e-signature is
claimed until a provider, webhook verification, and applicable compliance
workflow are implemented.

Permissions are stored separately from roles in `permissions` and
`role_permissions`, with assignments in `admin_roles`. Existing admin
accounts are automatically assigned `SUPER_ADMIN` during the
`001-rbac-foundation` migration, so the upgrade does not remove access.
Routes enforce permissions on the server; hiding a future UI control is not
used as an authorization boundary.

## Security notes — what's implemented and what isn't

Implemented and tested:
- Passwords hashed with scrypt (a memory-hard KDF, the same class of
  primitive as bcrypt/argon2), never stored or logged in plaintext.
- Sessions are random 32-byte tokens stored server-side in a `sessions`
  table with an expiry; the cookie is `HttpOnly`, `SameSite=Lax`, and
  `Secure` automatically once `NODE_ENV=production`.
- Every admin route checks the session on every request — verified above by
  hitting them with no cookie and getting 401.
- Rate limiting: 8 lead submissions per IP per 10 minutes, 10 login attempts
  per IP per 10 minutes (in-memory; fine for one instance, see note below).
- File uploads: type allow-list checked against both the extension and the
  declared MIME type, 10MB per file, 5 files per submission, random
  filenames, written under `uploads/` which is never served as a static
  path — confirmed by requesting `/uploads/...` directly and getting 404.
- Path traversal on file downloads is blocked by resolving the path and
  checking it's still inside `UPLOAD_DIR`.
- All SQL uses parameterized queries — no string concatenation into SQL,
  anywhere.
- Server-side validation on every field of the intake form (not just
  client-side), with field-specific error messages returned to the form.
- CSRF double-submit protection on authenticated state-changing admin routes.
- Security headers including CSP, HSTS, content-type sniffing protection,
  frame protection, referrer policy, and a restrictive permissions policy.
- No secrets or credentials anywhere in source; all read from `.env`.
- `robots.txt` excludes administrative/API routes and points crawlers to the
  generated `sitemap.xml`.
- `/healthz` provides a lightweight endpoint for uptime monitoring.

Explicitly **not** implemented, and you should know that before this goes
live with real client data:
- **Advanced client delivery features.** The initial client portal,
  ownership-scoped projects, milestones, tasks, and invoice visibility are
  implemented. Client messaging, file sharing, proposal presentation,
  contract signing, and a full project-management UI remain future work.
- **MFA/passkeys and password reset.** Current authentication uses secure
  password hashing and server-side sessions, but does not yet include those
  flows.
- **Payment providers and e-signatures.** Proposal/invoice/payment tables
  exist as a safe foundation, but no provider webhook or legally binding
  signature workflow is enabled.

### Mobile API contract

The `/api/v1` client API uses opaque server-side tokens. Access tokens expire
after 15 minutes. Refresh tokens expire after 30 days and are rotated on every
refresh; the previous refresh session is revoked. Mobile clients should store
tokens in platform-secure storage, send `Authorization: Bearer <accessToken>`,
refresh on `401`, and clear tokens on logout. The browser client portal is also
installable as a PWA from `/client`; this is a mobile web shell, not a claim
of a compiled native application.
- **Distributed rate limiting.** The limiter is a per-process in-memory Map.
  Fine for one server instance; if you ever run multiple instances behind a
  load balancer, move this to a shared store (Redis) or a reverse-proxy
  rate limiter (nginx, Cloudflare).
- **HTTPS.** This app speaks plain HTTP. In production, put it behind a
  reverse proxy (nginx, Caddy, or your host's built-in TLS) that terminates
  HTTPS and forwards to this server on localhost.

## Deployment

This is a long-running Node process that connects to MySQL and uses a local
uploads folder. The MySQL service and uploaded files must remain available
across deploys.

**Railway / Render (recommended, simplest path):**
1. Push this folder to a Git repo.
2. Create a new service from the repo. Start command: `npm start`.
3. Configure the `MYSQL_*` variables for a managed MySQL service and set
   `UPLOAD_DIR=/data/uploads` if uploads are stored on a persistent volume.
4. Set all the other `.env.example` variables in the platform's environment
   variable settings (never commit `.env`).
5. Run `npm run create-admin` once via the platform's shell/console feature
   after first deploy.

**VPS (Ubuntu, DigitalOcean/Linode/etc.):**
```bash
git clone <your repo> 7core-solution && cd 7core-solution
cp .env.example .env && nano .env
npm run create-admin
# run under a process manager so it survives reboots/crashes:
npx --yes pm2 start server.js --name 7core
pm2 save && pm2 startup
```
Put nginx or Caddy in front for HTTPS and to proxy port 80/443 → 3000.

**Docker:** no Dockerfile is included by default, but a minimal one is:
```dockerfile
FROM node:22-slim
WORKDIR /app
COPY . .
ENV NODE_ENV=production
EXPOSE 3000
CMD ["node", "server.js"]
```
Mount `/app/uploads` as a volume so uploaded files survive container
recreation. MySQL should be provided by a persistent database service.

## Backup

MySQL and the `uploads/` folder hold every client lead. Back them up
together — a lead's `lead_files` rows
reference files on disk, so restoring one without the other leaves broken
references or orphaned files.

```bash
# database backup (configure MYSQL_* first)
mysqldump --single-transaction --host="$MYSQL_HOST" --port="$MYSQL_PORT" \
  --user="$MYSQL_USER" --password="$MYSQL_PASSWORD" "$MYSQL_DATABASE" \
  > "7core-db-$(date +%F).sql"
tar -czf "7core-uploads-$(date +%F).tar.gz" uploads/
```

## Changing the WhatsApp number or email

One place: `.env`, the `WHATSAPP_NUMBER` and `CONTACT_EMAIL` values. Restart
the server. Every WhatsApp/email button across the public site, the
start-project page, and the admin dashboard reads from `GET /api/config` or
from the lead's own submitted contact details — nothing is hardcoded into
the frontend files.

## Extending the stack

If you later have network access and want the "conventional" stack:
- **Express**: `server.js` already routes by method+path in one place;
  wrapping each handler in `app.get(...)`/`app.post(...)` is mechanical.
- **bcrypt / multer / nodemailer**: `server/auth.js`, `server/multipart.js`,
  and `server/notify.js` are self-contained and were written specifically so
  they could be replaced wholesale without touching callers.

## Verification

The MySQL migration was syntax-checked, the MySQL driver was installed, and
the legacy SQLite source was inspected read-only to confirm that all 24
expected tables are present. End-to-end application tests against MySQL
still need to be run after configuring a reachable MySQL server; no local
MySQL server was available during this change.
