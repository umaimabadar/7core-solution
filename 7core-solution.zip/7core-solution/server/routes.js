// server/routes.js
// All REST endpoints. Plain Node http (no Express — none installable here),
// but the shape mirrors a normal Express app: a routeTable of
// "METHOD path-regex" -> handler(req, res, params).
"use strict";
const crypto = require("node:crypto");
const fs = require("node:fs");
const { run, get, all } = require("./db");
const auth = require("./auth");
const { parseMultipart } = require("./multipart");
const { storeUploadedFile, resolveStoredFile, removeLeadFiles } = require("./files");
const { notifyNewLead } = require("./notify");

// ---------- tiny helpers ----------
function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}
function readJSON(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > 2 * 1024 * 1024) {
        reject(Object.assign(new Error("Payload too large"), { status: 413 }));
        req.destroy();
        return;
      }
      data += c;
    });
    req.on("end", () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(Object.assign(new Error("Invalid JSON"), { status: 400 }));
      }
    });
    req.on("error", reject);
  });
}
function esc(s) {
  return String(s == null ? "" : s);
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;
const ADMIN_ROLES = ["SUPER_ADMIN", "ADMIN", "SALES"];
const PROJECT_STATUSES = [
  "PLANNING",
  "DESIGN",
  "DEVELOPMENT",
  "TESTING",
  "REVIEW",
  "DEPLOYMENT",
  "COMPLETED",
  "ON_HOLD",
  "CANCELLED",
];
const TASK_STATUSES = ["TODO", "IN_PROGRESS", "REVIEW", "DONE", "BLOCKED"];

// ---------- naive in-memory rate limiter ----------
// Per-process, per-IP sliding window. Good enough for a single small
// instance; swap for a shared store (Redis) behind a load balancer.
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  const b = buckets.get(key) || [];
  const fresh = b.filter((t) => now - t < windowMs);
  fresh.push(now);
  buckets.set(key, fresh);
  return fresh.length <= max;
}
function clientIP(req) {
  return (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown")
    .split(",")[0]
    .trim();
}

async function audit(req, adminId, action, entity, entityId, metadata = {}) {
  await run(
    "INSERT INTO audit_logs (admin_id, action, entity, entity_id, ip_address, metadata) VALUES (?,?,?,?,?,?)",
    [
      adminId || null,
      action,
      entity || null,
      entityId == null ? null : String(entityId),
      clientIP(req),
      JSON.stringify(metadata),
    ],
  );
}

const STATUSES = ["NEW", "CONTACTED", "IN_DISCUSSION", "PROPOSAL_SENT", "WON", "LOST"];

function leadRef() {
  const year = new Date().getFullYear();
  const rand = crypto.randomBytes(3).toString("hex").toUpperCase();
  return `7C-${year}-${rand}`;
}

async function fullLead(id) {
  const lead = await get("SELECT * FROM leads WHERE id = ?", [id]);
  if (!lead) return null;
  lead.services = (await all("SELECT service FROM lead_services WHERE lead_id = ?", [id])).map(
    (r) => r.service,
  );
  lead.priorities = (await all("SELECT priority FROM lead_priorities WHERE lead_id = ?", [id])).map(
    (r) => r.priority,
  );
  lead.references = (await all("SELECT url FROM lead_references WHERE lead_id = ?", [id])).map(
    (r) => r.url,
  );
  lead.files = await all(
    "SELECT id, original_name, mime_type, size, created_at FROM lead_files WHERE lead_id = ?",
    [id],
  );
  lead.notes = await all(
    "SELECT id, note, created_at, updated_at FROM lead_notes WHERE lead_id = ? ORDER BY created_at DESC",
    [id],
  );
  return lead;
}

// ==================================================================
// PUBLIC: POST /api/leads  (multipart/form-data OR application/json)
// ==================================================================
async function createLead(req, res) {
  if (!rateLimit("lead:" + clientIP(req), 8, 10 * 60 * 1000)) {
    return sendJSON(res, 429, {
      error: "Too many submissions. Please try again in a few minutes.",
    });
  }
  const ct = req.headers["content-type"] || "";
  let fields = {},
    files = [];
  try {
    if (ct.startsWith("multipart/form-data")) {
      const parsed = await parseMultipart(req, ct);
      fields = parsed.fields;
      files = parsed.files;
    } else {
      fields = await readJSON(req);
    }
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }

  const errors = {};
  const name = (fields.name || "").trim();
  const email = (fields.email || "").trim();
  const whatsapp = (fields.whatsapp || "").trim();
  const description = (fields.description || fields.project_description || "").trim();
  let services = fields.services;
  if (typeof services === "string") {
    try {
      services = JSON.parse(services);
    } catch {
      services = services
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  services = Array.isArray(services) ? services.filter(Boolean) : [];

  if (name.length < 2) errors.name = "Please enter your name.";
  if (!EMAIL_RE.test(email)) errors.email = "Please enter a valid email.";
  if (whatsapp.replace(/\D/g, "").length < 7)
    errors.whatsapp = "Please enter a reachable WhatsApp/phone number.";
  if (!services.length) errors.services = "Pick at least one service.";
  if (description.length < 10) errors.description = "Tell us a little more about the project.";
  if (Object.keys(errors).length)
    return sendJSON(res, 422, { error: "Validation failed", fields: errors });

  let priorities = fields.priorities;
  if (typeof priorities === "string") {
    try {
      priorities = JSON.parse(priorities);
    } catch {
      priorities = [];
    }
  }
  priorities = Array.isArray(priorities) ? priorities.filter(Boolean) : [];

  let references = fields.references;
  if (typeof references === "string") {
    try {
      references = JSON.parse(references);
    } catch {
      references = references
        .split(/[\n,]/)
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }
  references = Array.isArray(references) ? references.filter(Boolean).slice(0, 10) : [];

  const ref = leadRef();
  const now = new Date();
  const result = await run(
    `INSERT INTO leads (ref,name,company,email,whatsapp,phone,country,city,preferred_contact,
       project_name,project_description,problem,goal,target_audience,requirements,budget,timeline,
       additional_information,status,source,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      ref,
      name,
      fields.company || null,
      email,
      whatsapp,
      fields.phone || null,
      fields.country || null,
      fields.city || null,
      fields.preferred_contact || fields.preferredContact || null,
      fields.project_name || fields.projectName || null,
      description,
      fields.problem || null,
      fields.goal || null,
      fields.target_audience || fields.audience || null,
      fields.requirements || fields.features || null,
      fields.budget || null,
      fields.timeline || null,
      fields.additional_information || fields.additional || null,
      "NEW",
      "Website",
      now,
      now,
    ],
  );
  const leadId = result.lastInsertRowid;

  for (const service of services)
    await run("INSERT INTO lead_services (lead_id, service) VALUES (?,?)", [leadId, service]);
  for (const priority of priorities)
    await run("INSERT INTO lead_priorities (lead_id, priority) VALUES (?,?)", [leadId, priority]);
  for (const reference of references)
    await run("INSERT INTO lead_references (lead_id, url) VALUES (?,?)", [leadId, reference]);

  const savedFiles = [];
  for (const f of files.slice(0, 5)) {
    try {
      const meta = storeUploadedFile(f, ref);
      await run(
        "INSERT INTO lead_files (lead_id, original_name, stored_name, mime_type, size, path) VALUES (?,?,?,?,?,?)",
        [leadId, meta.original_name, meta.stored_name, meta.mime_type, meta.size, meta.path],
      );
      savedFiles.push(meta.original_name);
    } catch (err) {
      // A bad file shouldn't kill a lead that's otherwise valid, but the
      // client should still know it wasn't stored.
      savedFiles.push(`${f.filename} — rejected: ${err.message}`);
    }
  }

  notifyNewLead({
    ref,
    name,
    email,
    whatsapp,
    services,
    budget: fields.budget,
    timeline: fields.timeline,
  }).catch(() => {});

  sendJSON(res, 201, { ok: true, ref, leadId, filesReceived: savedFiles });
}

// ==================================================================
// ADMIN AUTH
// ==================================================================
async function login(req, res) {
  if (!rateLimit("login:" + clientIP(req), 10, 10 * 60 * 1000)) {
    return sendJSON(res, 429, { error: "Too many login attempts. Please wait and try again." });
  }
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";
  const admin = await get("SELECT * FROM admins WHERE email = ?", [email]);
  if (!admin || !auth.verifyPassword(password, admin.password_hash)) {
    await audit(req, null, "LOGIN_FAILED", "admin", email);
    return sendJSON(res, 401, { error: "Invalid email or password." });
  }
  const session = await auth.createSession(admin.id);
  auth.setSessionCookie(req, res, session.id, session.expires);
  const csrf = auth.createCsrfToken();
  auth.setCsrfCookie(req, res, csrf);
  await audit(req, admin.id, "LOGIN", "admin", admin.id);
  sendJSON(res, 200, { ok: true, admin: { id: admin.id, email: admin.email }, csrfToken: csrf });
}

async function clientLogin(req, res) {
  if (!rateLimit("client-login:" + clientIP(req), 10, 10 * 60 * 1000)) {
    return sendJSON(res, 429, { error: "Too many login attempts. Please wait and try again." });
  }

  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const email = (body.email || "").trim().toLowerCase();
  const account = await get("SELECT * FROM client_accounts WHERE email = ?", [email]);
  if (!account || !auth.verifyPassword(body.password || "", account.password_hash)) {
    return sendJSON(res, 401, { error: "Invalid email or password." });
  }
  const session = await auth.createClientSession(account.id);
  auth.setClientSessionCookie(res, session.id, session.expires);
  sendJSON(res, 200, { ok: true });
}

async function mobileLogin(req, res) {
  if (!rateLimit("mobile-login:" + clientIP(req), 10, 10 * 60 * 1000))
    return sendJSON(res, 429, { error: "Too many login attempts. Please try again later." });
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const email = (body.email || "").trim().toLowerCase();
  const account = await get("SELECT * FROM client_accounts WHERE email = ?", [email]);
  if (!account || !auth.verifyPassword(body.password || "", account.password_hash))
    return sendJSON(res, 401, { error: "Invalid email or password." });
  sendJSON(res, 200, {
    tokenType: "Bearer",
    ...await auth.createMobileSession(account.id, String(body.deviceName || "").slice(0, 80)),
  });
}

async function mobileRefresh(req, res) {
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const client = await auth.getMobileClientByRefreshToken(body.refreshToken);
  if (!client) return sendJSON(res, 401, { error: "Invalid or expired mobile refresh token." });
  sendJSON(res, 200, {
    tokenType: "Bearer",
    ...await auth.rotateMobileSession(
      client.mobile_session_id,
      client.account_id,
      String(body.deviceName || "").slice(0, 80),
    ),
  });
}

async function mobileLogout(req, res) {
  const client = await auth.requireMobileClient(req, res);
  if (!client) return;
  await auth.revokeMobileSession(client.mobile_session_id);
  sendJSON(res, 200, { ok: true });
}

async function mobileDashboard(req, res) {
  const client = await auth.requireMobileClient(req, res);
  if (!client) return;
  const projects = await all(
    "SELECT id, name, description, status, progress, start_date, deadline, priority, updated_at FROM projects WHERE client_id = ? ORDER BY updated_at DESC",
    [client.client_id],
  );
  const ids = projects.map((p) => p.id);
  const milestones = ids.length
    ? await all(
        `SELECT id, project_id, name, status, progress, due_date FROM milestones WHERE project_id IN (${ids.map(() => "?").join(",")}) ORDER BY due_date ASC`,
        ids,
      )
    : [];
  const tasks = ids.length
    ? await all(
        `SELECT id, project_id, title, status, priority, due_date FROM tasks WHERE project_id IN (${ids.map(() => "?").join(",")}) ORDER BY due_date ASC`,
        ids,
      )
    : [];
  const invoices = await all(
    "SELECT id, number, currency, total, due_date, status FROM invoices WHERE client_id = ? ORDER BY due_date ASC",
    [client.client_id],
  );
  sendJSON(res, 200, {
    data: {
      client: {
        id: client.client_id,
        name: client.name,
        company: client.company,
        email: client.email,
      },
      projects,
      milestones,
      tasks,
      invoices,
    },
    meta: { apiVersion: "v1" },
  });
}

async function mobileMe(req, res) {
  const client = await auth.requireMobileClient(req, res);
  if (!client) return;
  sendJSON(res, 200, {
    data: { id: client.client_id, name: client.name, company: client.company, email: client.email },
    meta: { apiVersion: "v1" },
  });
}

async function clientLogout(req, res) {
  const client = await auth.requireClient(req, res);
  if (!client) return;
  const cookies = auth.parseCookies(req);
  if (cookies[auth.CLIENT_COOKIE_NAME])
    await run("DELETE FROM client_sessions WHERE id = ?", [cookies[auth.CLIENT_COOKIE_NAME]]);
  auth.clearClientSessionCookie(res);
  sendJSON(res, 200, { ok: true });
}

async function clientDashboard(req, res) {
  const client = await auth.requireClient(req, res);
  if (!client) return;
  const projects = await all(
    `SELECT id, name, description, status, progress, start_date, deadline, priority, updated_at
       FROM projects WHERE client_id = ? ORDER BY updated_at DESC`,
    [client.client_id],
  );
  const projectIds = projects.map((p) => p.id);
  const milestones = projectIds.length
    ? await all(
        `SELECT id, project_id, name, status, progress, due_date FROM milestones WHERE project_id IN (${projectIds.map(() => "?").join(",")}) ORDER BY due_date ASC`,
        projectIds,
      )
    : [];
  const tasks = projectIds.length
    ? await all(
        `SELECT id, project_id, title, status, priority, due_date FROM tasks WHERE project_id IN (${projectIds.map(() => "?").join(",")}) ORDER BY due_date ASC`,
        projectIds,
      )
    : [];
  const invoices = await all(
    `SELECT id, number, currency, total, due_date, status FROM invoices WHERE client_id = ? ORDER BY due_date ASC`,
    [client.client_id],
  );
  sendJSON(res, 200, {
    client: {
      id: client.client_id,
      name: client.name,
      company: client.company,
      email: client.email,
    },
    projects,
    milestones,
    tasks,
    invoices,
  });
}

async function clientMe(req, res) {
  const client = await auth.requireClient(req, res);
  if (!client) return;
  sendJSON(res, 200, {
    client: {
      id: client.client_id,
      name: client.name,
      company: client.company,
      email: client.email,
    },
  });
}

async function requireAdminPermission(req, res, permission) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin || !await auth.requirePermission(req, res, admin, permission)) return null;
  return admin;
}

async function createClient(req, res) {
  const admin = await requireAdminPermission(req, res, "CLIENTS_MANAGE");
  if (!admin) return;
  if (!auth.requireCSRF(req, res)) return;
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const name = (body.name || "").trim();
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";
  if (name.length < 2 || !EMAIL_RE.test(email))
    return sendJSON(res, 422, { error: "Name and valid email are required." });
  if (password.length < 10)
    return sendJSON(res, 422, { error: "Client password must be at least 10 characters." });
  if (await get("SELECT id FROM client_accounts WHERE email = ?", [email]))
    return sendJSON(res, 409, { error: "A client account with that email already exists." });
  const client = await run(
    "INSERT INTO clients (name, company, email, whatsapp, phone, website, address, notes) VALUES (?,?,?,?,?,?,?,?)",
    [
      name,
      body.company || null,
      email,
      body.whatsapp || null,
      body.phone || null,
      body.website || null,
      body.address || null,
      body.notes || null,
    ],
  );
  await run("INSERT INTO client_accounts (client_id, email, password_hash) VALUES (?,?,?)", [
    client.lastInsertRowid,
    email,
    auth.hashPassword(password),
  ]);
  await audit(req, admin.id, "CLIENT_CREATED", "client", client.lastInsertRowid);
  sendJSON(res, 201, { ok: true, id: client.lastInsertRowid });
}

async function listClients(req, res) {
  const admin = await requireAdminPermission(req, res, "CLIENTS_VIEW");
  if (!admin) return;
  sendJSON(res, 200, {
    clients: await all(
      `SELECT c.id, c.name, c.company, c.email, c.phone, c.created_at,
              COUNT(DISTINCT p.id) AS project_count
       FROM clients c LEFT JOIN projects p ON p.client_id = c.id
       GROUP BY c.id ORDER BY c.created_at DESC`,
    ),
  });
}

async function createProject(req, res) {
  const admin = await requireAdminPermission(req, res, "PROJECTS_MANAGE");
  if (!admin) return;
  if (!auth.requireCSRF(req, res)) return;
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const client = await get("SELECT id FROM clients WHERE id = ?", [Number(body.client_id)]);
  if (!client) return sendJSON(res, 404, { error: "Client not found." });
  if (!body.name || body.name.trim().length < 2)
    return sendJSON(res, 422, { error: "Project name is required." });
  const status = body.status || "PLANNING";
  if (!PROJECT_STATUSES.includes(status))
    return sendJSON(res, 422, { error: "Invalid project status.", allowed: PROJECT_STATUSES });
  const result = await run(
    `INSERT INTO projects (client_id, name, description, budget, start_date, deadline, status, priority, technology_stack, repository_reference, deployment_information)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [
      client.id,
      (body.name || "").trim(),
      body.description || null,
      body.budget || null,
      body.start_date || null,
      body.deadline || null,
      status,
      body.priority || "NORMAL",
      body.technology_stack || null,
      body.repository_reference || null,
      body.deployment_information || null,
    ],
  );
  await audit(req, admin.id, "PROJECT_CREATED", "project", result.lastInsertRowid, {
    clientId: client.id,
  });
  sendJSON(res, 201, { ok: true, id: result.lastInsertRowid });
}

async function updateTask(req, res, params) {
  const admin = await requireAdminPermission(req, res, "PROJECTS_MANAGE");
  if (!admin) return;
  if (!auth.requireCSRF(req, res)) return;
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  if (body.status && !TASK_STATUSES.includes(body.status))
    return sendJSON(res, 422, { error: "Invalid task status.", allowed: TASK_STATUSES });
  const task = await get("SELECT id FROM tasks WHERE id = ?", [Number(params.id)]);
  if (!task) return sendJSON(res, 404, { error: "Task not found." });
  await run(
    "UPDATE tasks SET status = COALESCE(?, status), priority = COALESCE(?, priority), due_date = COALESCE(?, due_date), updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [body.status || null, body.priority || null, body.due_date || null, task.id],
  );
  await audit(req, admin.id, "TASK_UPDATED", "task", task.id, { status: body.status || null });
  sendJSON(res, 200, { ok: true });
}

async function csrf(req, res) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  const token = auth.createCsrfToken();
  auth.setCsrfCookie(req, res, token);
  sendJSON(res, 200, { csrfToken: token });
}

async function logout(req, res) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!auth.requireCSRF(req, res)) return;
  const cookies = auth.parseCookies(req);
  if (cookies[auth.COOKIE_NAME]) await auth.destroySession(cookies[auth.COOKIE_NAME]);
  auth.clearSessionCookie(res);
  auth.clearCsrfCookie(res);
  await audit(req, admin.id, "LOGOUT", "admin", admin.id);
  sendJSON(res, 200, { ok: true });
}

async function me(req, res) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  sendJSON(res, 200, { admin: { ...admin, access: await auth.getAdminAccess(admin.id) } });
}

async function requireUserManagement(req, res) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return null;
  if (!await auth.requirePermission(req, res, admin, "MANAGE_USERS")) return null;
  return admin;
}

async function listAdminUsers(req, res) {
  const admin = await requireUserManagement(req, res);
  if (!admin) return;
  const users = (await all(
    `SELECT a.id, a.email, a.created_at, a.updated_at,
            COALESCE(GROUP_CONCAT(r.name SEPARATOR ','), '') AS roles
     FROM admins a
     LEFT JOIN admin_roles ar ON ar.admin_id = a.id
     LEFT JOIN roles r ON r.id = ar.role_id
     GROUP BY a.id
     ORDER BY a.created_at ASC`,
  )).map((user) => ({ ...user, roles: user.roles ? user.roles.split(",") : [] }));
  sendJSON(res, 200, { users, roles: ADMIN_ROLES });
}

async function roleId(role) {
  const row = await get("SELECT id FROM roles WHERE name = ?", [role]);
  return row ? row.id : null;
}

async function assignAdminRole(adminId, role) {
  const id = await roleId(role);
  if (!id) throw Object.assign(new Error("Invalid role"), { status: 422 });
  await run("DELETE FROM admin_roles WHERE admin_id = ?", [adminId]);
  await run("INSERT INTO admin_roles (admin_id, role_id) VALUES (?,?)", [adminId, id]);
}

async function createAdminUser(req, res) {
  const actor = await requireUserManagement(req, res);
  if (!actor) return;
  if (!auth.requireCSRF(req, res)) return;
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";
  const role = body.role || "ADMIN";
  if (!EMAIL_RE.test(email))
    return sendJSON(res, 422, { error: "Please provide a valid email address." });
  if (password.length < 10)
    return sendJSON(res, 422, { error: "Password must be at least 10 characters." });
  if (!ADMIN_ROLES.includes(role))
    return sendJSON(res, 422, { error: "Invalid role.", allowed: ADMIN_ROLES });
  if (await get("SELECT id FROM admins WHERE email = ?", [email]))
    return sendJSON(res, 409, { error: "An admin with that email already exists." });
  const result = await run("INSERT INTO admins (email, password_hash) VALUES (?,?)", [
    email,
    auth.hashPassword(password),
  ]);
  await assignAdminRole(result.lastInsertRowid, role);
  await audit(req, actor.id, "ADMIN_CREATED", "admin", result.lastInsertRowid, { role });
  sendJSON(res, 201, { ok: true, id: result.lastInsertRowid, email, role });
}

async function updateAdminUser(req, res, params) {
  const actor = await requireUserManagement(req, res);
  if (!actor) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  const target = await get("SELECT id, email FROM admins WHERE id = ?", [id]);
  if (!target) return sendJSON(res, 404, { error: "Admin not found." });
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const role = body.role;
  const password = body.password || "";
  if (role !== undefined && !ADMIN_ROLES.includes(role))
    return sendJSON(res, 422, { error: "Invalid role.", allowed: ADMIN_ROLES });
  if (password && password.length < 10)
    return sendJSON(res, 422, { error: "Password must be at least 10 characters." });
  if (id === actor.id && role && role !== "SUPER_ADMIN")
    return sendJSON(res, 422, { error: "You cannot remove your own SUPER_ADMIN access." });
  if (role && role !== "SUPER_ADMIN" && target.email) {
    const count = await get(
      `SELECT COUNT(*) AS n FROM admins a
       JOIN admin_roles ar ON ar.admin_id = a.id
       JOIN roles r ON r.id = ar.role_id
       WHERE r.name = 'SUPER_ADMIN'`,
    );
    const currentRole = await get(
      `SELECT r.name FROM admin_roles ar JOIN roles r ON r.id = ar.role_id WHERE ar.admin_id = ?`,
      [id],
    );
    if (currentRole && currentRole.name === "SUPER_ADMIN" && count.n <= 1) {
      return sendJSON(res, 422, { error: "At least one SUPER_ADMIN must remain." });
    }
  }
  if (password)
    await run("UPDATE admins SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [
      auth.hashPassword(password),
      id,
    ]);
  if (role) await assignAdminRole(id, role);
  await audit(req, actor.id, password ? "ADMIN_PASSWORD_RESET" : "ADMIN_ROLE_UPDATED", "admin", id, {
    role: role || null,
  });
  sendJSON(res, 200, { ok: true });
}

async function deleteAdminUser(req, res, params) {
  const actor = await requireUserManagement(req, res);
  if (!actor) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  if (id === actor.id) return sendJSON(res, 422, { error: "You cannot delete your own account." });
  const target = await get("SELECT id FROM admins WHERE id = ?", [id]);
  if (!target) return sendJSON(res, 404, { error: "Admin not found." });
  const superCount = await get(
    `SELECT COUNT(*) AS n FROM admins a
     JOIN admin_roles ar ON ar.admin_id = a.id
     JOIN roles r ON r.id = ar.role_id
     WHERE r.name = 'SUPER_ADMIN'`,
  );
  const targetRole = await get(
    `SELECT r.name FROM admin_roles ar JOIN roles r ON r.id = ar.role_id WHERE ar.admin_id = ?`,
    [id],
  );
  if (targetRole && targetRole.name === "SUPER_ADMIN" && superCount.n <= 1) {
    return sendJSON(res, 422, { error: "At least one SUPER_ADMIN must remain." });
  }
  await run("DELETE FROM admins WHERE id = ?", [id]);
  await audit(req, actor.id, "ADMIN_DELETED", "admin", id);
  sendJSON(res, 200, { ok: true });
}

async function listAuditLogs(req, res, query) {
  const admin = await requireUserManagement(req, res);
  if (!admin) return;
  const limit = Math.min(Math.max(Number(query.limit) || 100, 1), 200);
  const rows = (await all(
    `SELECT l.id, l.action, l.entity, l.entity_id, l.ip_address, l.metadata, l.created_at,
            a.email AS admin_email
     FROM audit_logs l
     LEFT JOIN admins a ON a.id = l.admin_id
     ORDER BY l.created_at DESC, l.id DESC
     LIMIT ?`,
    [limit],
  )).map((row) => {
    let metadata = {};
    try {
      metadata = row.metadata ? JSON.parse(row.metadata) : {};
    } catch {
      metadata = {};
    }
    return { ...row, metadata };
  });
  sendJSON(res, 200, { logs: rows });
}

// ==================================================================
// ADMIN: leads
// ==================================================================
async function stats(req, res) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "ANALYTICS_VIEW")) return;
  const rows = await all("SELECT status, COUNT(*) as n FROM leads GROUP BY status");
  const out = { TOTAL: 0 };
  STATUSES.forEach((s) => (out[s] = 0));
  rows.forEach((r) => {
    out[r.status] = r.n;
    out.TOTAL += r.n;
  });
  sendJSON(res, 200, out);
}

async function listLeads(req, res, query) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_VIEW")) return;
  const where = [];
  const params = [];
  if (query.status) {
    where.push("status = ?");
    params.push(query.status);
  }
  if (query.budget) {
    where.push("budget = ?");
    params.push(query.budget);
  }
  if (query.timeline) {
    where.push("timeline = ?");
    params.push(query.timeline);
  }
  if (query.service) {
    where.push("id IN (SELECT lead_id FROM lead_services WHERE service = ?)");
    params.push(query.service);
  }
  if (query.q) {
    where.push(
      `(name LIKE ? OR email LIKE ? OR company LIKE ? OR phone LIKE ? OR whatsapp LIKE ? OR ref LIKE ? OR project_name LIKE ?)`,
    );
    const like = `%${query.q}%`;
    params.push(like, like, like, like, like, like, like);
  }
  let sort = "created_at DESC";
  if (query.sort === "oldest") sort = "created_at ASC";
  else if (query.sort === "updated") sort = "updated_at DESC";
  else if (query.sort === "budget") sort = "budget DESC";
  else if (query.sort === "status") sort = "status ASC";

  const sql = `SELECT id, ref, name, company, email, budget, timeline, status, created_at, updated_at
               FROM leads ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY ${sort} LIMIT 200`;
  const rows = await all(sql, params);
  const ids = rows.map((r) => r.id);
  const svcByLead = {};
  if (ids.length) {
    (await all(
      `SELECT lead_id, service FROM lead_services WHERE lead_id IN (${ids.map(() => "?").join(",")})`,
      ids,
    )).forEach((r) => {
      (svcByLead[r.lead_id] ||= []).push(r.service);
    });
  }
  rows.forEach((r) => {
    r.services = svcByLead[r.id] || [];
  });
  sendJSON(res, 200, { leads: rows });
}

async function getLead(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_VIEW")) return;
  const lead = await fullLead(Number(params.id));
  if (!lead) return sendJSON(res, 404, { error: "Lead not found" });
  sendJSON(res, 200, { lead });
}

async function patchLead(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_EDIT")) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  const existing = await get("SELECT id, ref, status FROM leads WHERE id = ?", [id]);
  if (!existing) return sendJSON(res, 404, { error: "Lead not found" });
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status))
      return sendJSON(res, 422, { error: "Invalid status", allowed: STATUSES });
    await run(`UPDATE leads SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [
      body.status,
      id,
    ]);
    await audit(req, admin.id, "LEAD_STATUS_UPDATED", "lead", id, {
      from: existing.status,
      to: body.status,
    });
  }
  sendJSON(res, 200, { lead: await fullLead(id) });
}

async function deleteLead(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_DELETE")) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  const existing = await get("SELECT id, ref FROM leads WHERE id = ?", [id]);
  if (!existing) return sendJSON(res, 404, { error: "Lead not found" });
  await run("DELETE FROM leads WHERE id = ?", [id]); // cascades via FKs
  removeLeadFiles(existing.ref);
  await audit(req, admin.id, "LEAD_DELETED", "lead", id, { ref: existing.ref });
  sendJSON(res, 200, { ok: true });
}

async function addNote(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_NOTES")) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  const lead = await get("SELECT id FROM leads WHERE id = ?", [id]);
  if (!lead) return sendJSON(res, 404, { error: "Lead not found" });
  let body;
  try {
    body = await readJSON(req);
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const note = (body.note || "").trim();
  if (!note) return sendJSON(res, 422, { error: "Note cannot be empty" });
  if (note.length > 4000) return sendJSON(res, 422, { error: "Note is too long" });
  await run("INSERT INTO lead_notes (lead_id, note) VALUES (?,?)", [id, note]);
  await audit(req, admin.id, "LEAD_NOTE_CREATED", "lead", id);
  sendJSON(res, 201, {
    notes: await all(
      "SELECT id, note, created_at, updated_at FROM lead_notes WHERE lead_id = ? ORDER BY created_at DESC",
      [id],
    ),
  });
}

async function addFilesToLead(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_FILES_MANAGE")) return;
  if (!auth.requireCSRF(req, res)) return;
  const id = Number(params.id);
  const lead = await get("SELECT id, ref FROM leads WHERE id = ?", [id]);
  if (!lead) return sendJSON(res, 404, { error: "Lead not found" });
  const ct = req.headers["content-type"] || "";
  if (!ct.startsWith("multipart/form-data"))
    return sendJSON(res, 400, { error: "Expected multipart/form-data" });
  let files;
  try {
    ({ files } = await parseMultipart(req, ct));
  } catch (err) {
    return sendJSON(res, err.status || 400, { error: err.message });
  }
  const saved = [];
  for (const f of files.slice(0, 5)) {
    try {
      const meta = storeUploadedFile(f, lead.ref);
      await run(
        "INSERT INTO lead_files (lead_id, original_name, stored_name, mime_type, size, path) VALUES (?,?,?,?,?,?)",
        [id, meta.original_name, meta.stored_name, meta.mime_type, meta.size, meta.path],
      );
      saved.push(meta.original_name);
      await audit(req, admin.id, "LEAD_FILE_UPLOADED", "lead", id, {
        filename: meta.original_name,
        size: meta.size,
      });
    } catch (err) {
      return sendJSON(res, err.status || 400, { error: err.message });
    }
  }
  sendJSON(res, 201, {
    saved,
    files: await all(
      "SELECT id, original_name, mime_type, size, created_at FROM lead_files WHERE lead_id = ?",
      [id],
    ),
  });
}

// GET /api/leads/:id/files/:fileId — auth-gated file download
async function downloadFile(req, res, params) {
  const admin = await auth.requireAdmin(req, res);
  if (!admin) return;
  if (!await auth.requirePermission(req, res, admin, "LEADS_FILES_VIEW")) return;
  const row = await get("SELECT * FROM lead_files WHERE id = ? AND lead_id = ?", [
    Number(params.fileId),
    Number(params.id),
  ]);
  if (!row) return sendJSON(res, 404, { error: "File not found" });
  const full = resolveStoredFile(row.path);
  if (!full) return sendJSON(res, 404, { error: "File missing on disk" });
  await audit(req, admin.id, "LEAD_FILE_DOWNLOADED", "lead", params.id, { fileId: row.id });
  res.writeHead(200, {
    "Content-Type": row.mime_type || "application/octet-stream",
    "Content-Disposition": `attachment; filename="${row.original_name.replace(/"/g, "")}"`,
  });
  fs.createReadStream(full).pipe(res);
}

module.exports = {
  sendJSON,
  esc,
  STATUSES,
  createLead,
  login,
  logout,
  csrf,
  me,
  listAdminUsers,
  createAdminUser,
  updateAdminUser,
  deleteAdminUser,
  listAuditLogs,
  clientLogin,
  clientLogout,
  clientDashboard,
  clientMe,
  createClient,
  listClients,
  createProject,
  updateTask,
  mobileLogin,
  mobileRefresh,
  mobileLogout,
  mobileDashboard,
  mobileMe,
  stats,
  listLeads,
  getLead,
  patchLead,
  deleteLead,
  addNote,
  addFilesToLead,
  downloadFile,
};
