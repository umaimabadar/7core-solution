// server/notify.js
// Best-effort email notification when a new lead comes in. If SMTP_HOST is
// not set, this silently does nothing — lead saving and the client success
// page never depend on it. No external mail package is used (none can be
// installed here); this speaks raw SMTP over a TCP socket, which is enough
// for a single plain-text notification and works with most providers that
// accept STARTTLS-less auth on 587/25 from a trusted app password, or can be
// pointed at a local mail relay. For anything more elaborate, swap this file
// for `nodemailer` once you have network access to `npm install` it — every
// other file just calls notifyNewLead(), so nothing else has to change.
"use strict";
const net = require("node:net");

function line(socket, text) {
  return new Promise((resolve) => {
    socket.write(text + "\r\n");
    resolve();
  });
}

function waitFor(socket, code) {
  return new Promise((resolve, reject) => {
    const onData = (d) => {
      const s = d.toString();
      if (s.startsWith(String(code))) {
        socket.off("data", onData);
        resolve(s);
      }
    };
    socket.on("data", onData);
    socket.once("error", reject);
  });
}

async function notifyNewLead(lead) {
  const host = process.env.SMTP_HOST;
  const to = process.env.NOTIFY_EMAIL || process.env.CONTACT_EMAIL;
  if (!host || !to) return { skipped: true };

  const port = Number(process.env.SMTP_PORT || 587);
  const from = process.env.SMTP_FROM || `7Core Solution <no-reply@7coresolution.com>`;
  const subject = `New 7Core project inquiry — ${lead.name}`;
  const body = [
    `New project inquiry received.`,
    ``,
    `Client: ${lead.name}${lead.company ? " (" + lead.company + ")" : ""}`,
    `Email: ${lead.email}`,
    `WhatsApp: ${lead.whatsapp}`,
    `Services: ${(lead.services || []).join(", ")}`,
    `Budget: ${lead.budget || "—"}`,
    `Timeline: ${lead.timeline || "—"}`,
    ``,
    `View in the admin dashboard: /admin`,
    `Reference: ${lead.ref}`,
  ].join("\r\n");

  try {
    const socket = net.createConnection(port, host);
    await new Promise((res, rej) => {
      socket.once("connect", res);
      socket.once("error", rej);
    });
    await waitFor(socket, 220);
    await line(socket, `EHLO 7coresolution.com`);
    await waitFor(socket, 250);
    if (process.env.SMTP_USER) {
      await line(socket, "AUTH LOGIN");
      await waitFor(socket, 334);
      await line(socket, Buffer.from(process.env.SMTP_USER).toString("base64"));
      await waitFor(socket, 334);
      await line(socket, Buffer.from(process.env.SMTP_PASS || "").toString("base64"));
      await waitFor(socket, 235);
    }
    await line(socket, `MAIL FROM:<${from.match(/<(.+)>/)?.[1] || from}>`);
    await waitFor(socket, 250);
    await line(socket, `RCPT TO:<${to}>`);
    await waitFor(socket, 250);
    await line(socket, "DATA");
    await waitFor(socket, 354);
    await line(socket, `From: ${from}\r\nTo: ${to}\r\nSubject: ${subject}\r\n\r\n${body}\r\n.`);
    await waitFor(socket, 250);
    await line(socket, "QUIT");
    socket.end();
    return { sent: true };
  } catch (err) {
    console.error("[7Core] email notification failed (lead was still saved):", err.message);
    return { sent: false, error: err.message };
  }
}

module.exports = { notifyNewLead };
