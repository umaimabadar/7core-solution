// Password hashing and database-backed session cookies.
"use strict";
const crypto = require("node:crypto");
const { run, get, all } = require("./db");

const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;
const COOKIE_NAME = "7core_session";
const CSRF_COOKIE_NAME = "7core_csrf";
const CSRF_HEADER = "x-csrf-token";
const CLIENT_COOKIE_NAME = "7core_client_session";
const MOBILE_ACCESS_TTL_MS = 1000 * 60 * 15;
const MOBILE_REFRESH_TTL_MS = 1000 * 60 * 60 * 24 * 30;

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(plain, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

function verifyPassword(plain, stored) {
  if (!stored || !stored.startsWith("scrypt$")) return false;
  const [, salt, hash] = stored.split("$");
  const check = crypto.scryptSync(plain, salt, 64).toString("hex");
  const a = Buffer.from(hash, "hex");
  const b = Buffer.from(check, "hex");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

async function createSession(adminId) {
  const id = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_TTL_MS).toISOString();
  await run("INSERT INTO sessions (id, admin_id, expires_at) VALUES (?,?,?)", [
    id,
    adminId,
    new Date(expires),
  ]);
  return { id, expires };
}

async function destroySession(id) {
  await run("DELETE FROM sessions WHERE id = ?", [id]);
}

async function getAdminBySession(sessionId) {
  if (!sessionId) return null;
  return (
    (await get(
      `SELECT a.id, a.email FROM sessions s
       JOIN admins a ON a.id = s.admin_id
       WHERE s.id = ? AND s.expires_at > CURRENT_TIMESTAMP`,
      [sessionId],
    )) || null
  );
}

async function getAdminAccess(adminId) {
  const roles = (await all(
    `SELECT r.name
     FROM admin_roles ar
     JOIN roles r ON r.id = ar.role_id
     WHERE ar.admin_id = ?
     ORDER BY r.name`,
    [adminId],
  )).map((row) => row.name);
  const permissions = (await all(
    `SELECT DISTINCT p.name
     FROM admin_roles ar
     JOIN role_permissions rp ON rp.role_id = ar.role_id
     JOIN permissions p ON p.id = rp.permission_id
     WHERE ar.admin_id = ?
     ORDER BY p.name`,
    [adminId],
  )).map((row) => row.name);
  return { roles, permissions };
}

async function hasPermission(adminId, permission) {
  return !!(await get(
    `SELECT 1
     FROM admin_roles ar
     JOIN role_permissions rp ON rp.role_id = ar.role_id
     JOIN permissions p ON p.id = rp.permission_id
     WHERE ar.admin_id = ? AND p.name = ?
     LIMIT 1`,
    [adminId, permission],
  ));
}

async function requirePermission(req, res, admin, permission) {
  if (!admin || (await hasPermission(admin.id, permission))) return true;
  res.writeHead(403, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "You do not have permission to perform this action." }));
  return false;
}

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  header.split(";").forEach((p) => {
    const i = p.indexOf("=");
    if (i === -1) return;
    out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function cookieIsSecure(req) {
  const forwardedProto = String((req && req.headers && req.headers["x-forwarded-proto"]) || "")
    .split(",")[0]
    .trim()
    .toLowerCase();
  if (forwardedProto) return forwardedProto === "https";
  if (req && req.socket && req.socket.encrypted) return true;
  return /^https:\/\//i.test(process.env.SITE_ORIGIN || "");
}

function appendCookie(res, cookie) {
  const existing = res.getHeader("Set-Cookie");
  const cookies =
    existing == null ? [] : Array.isArray(existing) ? existing.slice() : [String(existing)];
  cookies.push(cookie);
  res.setHeader("Set-Cookie", cookies);
}

function setSessionCookie(req, res, sessionId, expires) {
  const secure = cookieIsSecure(req) ? "; Secure" : "";
  appendCookie(
    res,
    `${COOKIE_NAME}=${sessionId}; Path=/; HttpOnly; SameSite=Lax; Expires=${new Date(expires).toUTCString()}${secure}`,
  );
}

function clearSessionCookie(res) {
  res.setHeader("Set-Cookie", `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

function createCsrfToken() {
  return crypto.randomBytes(32).toString("hex");
}

function setCsrfCookie(req, res, token) {
  const secure = cookieIsSecure(req) ? "; Secure" : "";
  appendCookie(res, `${CSRF_COOKIE_NAME}=${token}; Path=/; SameSite=Lax; Max-Age=3600${secure}`);
}

function clearCsrfCookie(res) {
  res.setHeader("Set-Cookie", `${CSRF_COOKIE_NAME}=; Path=/; SameSite=Lax; Max-Age=0`);
}

function requireCSRF(req, res) {
  const cookies = parseCookies(req);
  const cookieValue = cookies[CSRF_COOKIE_NAME];
  const headerValue = (
    req.headers[CSRF_HEADER] ||
    req.headers[CSRF_HEADER.toLowerCase()] ||
    ""
  ).toString();
  if (!cookieValue || !headerValue) {
    res.writeHead(403, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Missing CSRF token." }));
    return false;
  }
  try {
    if (cookieValue.length !== headerValue.length) throw new Error("Token mismatch");
    if (!crypto.timingSafeEqual(Buffer.from(cookieValue), Buffer.from(headerValue)))
      throw new Error("Token mismatch");
    return true;
  } catch {
    res.writeHead(403, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Invalid CSRF token." }));
    return false;
  }
}

async function createClientSession(accountId) {
  const id = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_TTL_MS).toISOString();
  await run("INSERT INTO client_sessions (id, client_account_id, expires_at) VALUES (?,?,?)", [
    id,
    accountId,
    new Date(expires),
  ]);
  return { id, expires };
}

async function getClientBySession(sessionId) {
  if (!sessionId) return null;
  return (
    (await get(
      `SELECT ca.id AS account_id, ca.email, c.id AS client_id, c.name, c.company
       FROM client_sessions cs
       JOIN client_accounts ca ON ca.id = cs.client_account_id
       JOIN clients c ON c.id = ca.client_id
       WHERE cs.id = ? AND cs.expires_at > CURRENT_TIMESTAMP`,
      [sessionId],
    )) || null
  );
}

function setClientSessionCookie(res, sessionId, expires) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${CLIENT_COOKIE_NAME}=${sessionId}; Path=/; HttpOnly; SameSite=Lax; Expires=${new Date(expires).toUTCString()}${secure}`,
  );
}

function clearClientSessionCookie(res) {
  res.setHeader("Set-Cookie", `${CLIENT_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

async function requireClient(req, res) {
  const cookies = parseCookies(req);
  const client = await getClientBySession(cookies[CLIENT_COOKIE_NAME]);
  if (!client) {
    res.writeHead(401, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Not authenticated" }));
    return null;
  }
  return client;
}

function tokenHash(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

async function createMobileSession(accountId, deviceName) {
  const accessToken = crypto.randomBytes(32).toString("base64url");
  const refreshToken = crypto.randomBytes(48).toString("base64url");
  const accessExpires = new Date(Date.now() + MOBILE_ACCESS_TTL_MS).toISOString();
  const refreshExpires = new Date(Date.now() + MOBILE_REFRESH_TTL_MS).toISOString();
  await run(
    `INSERT INTO mobile_sessions
     (client_account_id, access_token_hash, refresh_token_hash, access_expires_at, refresh_expires_at, device_name)
     VALUES (?,?,?,?,?,?)`,
    [
      accountId,
      tokenHash(accessToken),
      tokenHash(refreshToken),
      new Date(accessExpires),
      new Date(refreshExpires),
      deviceName || null,
    ],
  );
  return { accessToken, refreshToken, accessExpires, refreshExpires };
}

async function getMobileClientByAccessToken(token) {
  if (!token) return null;
  return (
    (await get(
      `SELECT ms.id AS mobile_session_id, ms.client_account_id AS account_id,
              ca.email, c.id AS client_id, c.name, c.company
       FROM mobile_sessions ms
       JOIN client_accounts ca ON ca.id = ms.client_account_id
       JOIN clients c ON c.id = ca.client_id
       WHERE ms.access_token_hash = ? AND ms.revoked_at IS NULL
         AND ms.access_expires_at > CURRENT_TIMESTAMP`,
      [tokenHash(token)],
    )) || null
  );
}

async function getMobileClientByRefreshToken(token) {
  if (!token) return null;
  return (
    (await get(
      `SELECT ms.id AS mobile_session_id, ms.client_account_id AS account_id,
              ca.email, c.id AS client_id, c.name, c.company
       FROM mobile_sessions ms
       JOIN client_accounts ca ON ca.id = ms.client_account_id
       JOIN clients c ON c.id = ca.client_id
       WHERE ms.refresh_token_hash = ? AND ms.revoked_at IS NULL
         AND ms.refresh_expires_at > CURRENT_TIMESTAMP`,
      [tokenHash(token)],
    )) || null
  );
}

async function rotateMobileSession(sessionId, accountId, deviceName) {
  await run(
    "UPDATE mobile_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE id = ? AND client_account_id = ?",
    [sessionId, accountId],
  );
  return createMobileSession(accountId, deviceName);
}

async function revokeMobileSession(sessionId) {
  await run("UPDATE mobile_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?", [sessionId]);
}

async function requireMobileClient(req, res) {
  const header = String(req.headers.authorization || "");
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const client = await getMobileClientByAccessToken(token);
  if (!client) {
    res.writeHead(401, { "Content-Type": "application/json", "WWW-Authenticate": "Bearer" });
    res.end(JSON.stringify({ error: "Invalid or expired mobile access token." }));
    return null;
  }
  return client;
}

async function requireAdmin(req, res) {
  const cookies = parseCookies(req);
  const admin = await getAdminBySession(cookies[COOKIE_NAME]);
  if (!admin) {
    res.writeHead(401, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Not authenticated" }));
    return null;
  }
  return admin;
}

module.exports = {
  COOKIE_NAME,
  CSRF_COOKIE_NAME,
  CSRF_HEADER,
  hashPassword,
  verifyPassword,
  createSession,
  destroySession,
  getAdminBySession,
  getAdminAccess,
  hasPermission,
  requirePermission,
  parseCookies,
  setSessionCookie,
  clearSessionCookie,
  createCsrfToken,
  setCsrfCookie,
  clearCsrfCookie,
  requireCSRF,
  requireAdmin,
  CLIENT_COOKIE_NAME,
  createClientSession,
  getClientBySession,
  setClientSessionCookie,
  clearClientSessionCookie,
  requireClient,
  createMobileSession,
  getMobileClientByAccessToken,
  getMobileClientByRefreshToken,
  rotateMobileSession,
  revokeMobileSession,
  requireMobileClient,
};
