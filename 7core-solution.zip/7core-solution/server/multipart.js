// server/multipart.js
// A small multipart/form-data parser. No external package is available in
// this deployment path (no network to install multer/busboy), so this reads
// the raw request body and splits it on the boundary by hand. Good enough
// for a project-intake form: a handful of text fields plus a few files.
"use strict";

const MAX_BODY_BYTES = 25 * 1024 * 1024; // 25MB total request cap

function parseContentDisposition(header) {
  const out = {};
  header
    .split(";")
    .slice(1)
    .forEach((part) => {
      const m = part.trim().match(/^([a-zA-Z0-9]+)="(.*)"$/);
      if (m) out[m[1]] = m[2];
    });
  return out;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error("Request too large"), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

// Returns { fields: {name: value}, files: [{fieldName, filename, mimeType, buffer}] }
async function parseMultipart(req, contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  const boundary = m ? m[1] || m[2] : null;
  if (!boundary) throw Object.assign(new Error("Missing multipart boundary"), { status: 400 });

  const body = await readBody(req);
  const boundaryBuf = Buffer.from(`--${boundary}`);
  const fields = {};
  const files = [];

  let start = body.indexOf(boundaryBuf);
  while (start !== -1) {
    const next = body.indexOf(boundaryBuf, start + boundaryBuf.length);
    if (next === -1) break;
    // part is between end of this boundary line and start of next boundary
    let partStart = start + boundaryBuf.length;
    // skip CRLF after boundary
    if (body[partStart] === 0x0d && body[partStart + 1] === 0x0a) partStart += 2;
    let partEnd = next;
    // strip trailing CRLF before next boundary
    if (body[partEnd - 2] === 0x0d && body[partEnd - 1] === 0x0a) partEnd -= 2;

    if (partEnd > partStart) {
      const headerEnd = body.indexOf("\r\n\r\n", partStart);
      if (headerEnd !== -1 && headerEnd < partEnd) {
        const headerText = body.slice(partStart, headerEnd).toString("utf8");
        const contentStart = headerEnd + 4;
        const content = body.slice(contentStart, partEnd);

        const dispositionLine =
          headerText.split("\r\n").find((l) => /content-disposition/i.test(l)) || "";
        const disp = parseContentDisposition(dispositionLine);
        const typeLine = headerText.split("\r\n").find((l) => /content-type/i.test(l));
        const mimeType = typeLine ? typeLine.split(":")[1].trim() : null;

        if (disp.filename !== undefined) {
          if (disp.filename) {
            files.push({
              fieldName: disp.name,
              filename: disp.filename,
              mimeType,
              buffer: content,
            });
          }
        } else if (disp.name) {
          fields[disp.name] = content.toString("utf8");
        }
      }
    }
    start = next;
  }
  return { fields, files };
}

module.exports = { parseMultipart, MAX_BODY_BYTES };
