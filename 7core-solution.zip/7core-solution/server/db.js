// MySQL connection, schema initialization, and query helpers.
"use strict";
const mysql = require("mysql2/promise");

let pool;

const tableNames = [
  "admins",
  "roles",
  "permissions",
  "admin_roles",
  "role_permissions",
  "sessions",
  "audit_logs",
  "leads",
  "lead_services",
  "lead_priorities",
  "lead_references",
  "lead_files",
  "lead_notes",
  "clients",
  "client_accounts",
  "client_sessions",
  "mobile_sessions",
  "projects",
  "milestones",
  "tasks",
  "proposals",
  "invoices",
  "payments",
  "schema_migrations",
];

const schema = [
  `CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(320) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS roles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    description TEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS permissions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS admin_roles (
    admin_id BIGINT UNSIGNED NOT NULL,
    role_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (admin_id, role_id),
    CONSTRAINT fk_admin_roles_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
    CONSTRAINT fk_admin_roles_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS role_permissions (
    role_id BIGINT UNSIGNED NOT NULL,
    permission_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_role_permissions_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS sessions (
    id CHAR(64) NOT NULL PRIMARY KEY,
    admin_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    expires_at DATETIME(3) NOT NULL,
    CONSTRAINT fk_sessions_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    admin_id BIGINT UNSIGNED,
    action VARCHAR(100) NOT NULL,
    entity VARCHAR(100),
    entity_id MEDIUMTEXT,
    ip_address MEDIUMTEXT,
    metadata MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_audit_created (created_at),
    INDEX idx_audit_admin (admin_id),
    CONSTRAINT fk_audit_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS leads (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ref VARCHAR(32) NOT NULL UNIQUE,
    name MEDIUMTEXT NOT NULL,
    company MEDIUMTEXT,
    email MEDIUMTEXT NOT NULL,
    whatsapp MEDIUMTEXT NOT NULL,
    phone MEDIUMTEXT,
    country MEDIUMTEXT,
    city MEDIUMTEXT,
    preferred_contact MEDIUMTEXT,
    project_name MEDIUMTEXT,
    project_description MEDIUMTEXT,
    problem MEDIUMTEXT,
    goal MEDIUMTEXT,
    target_audience MEDIUMTEXT,
    requirements MEDIUMTEXT,
    budget MEDIUMTEXT,
    timeline MEDIUMTEXT,
    additional_information MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'NEW',
    source VARCHAR(120) NOT NULL DEFAULT 'Website',
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_leads_status (status),
    INDEX idx_leads_created (created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS lead_services (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    service MEDIUMTEXT NOT NULL,
    INDEX idx_lsvc_lead (lead_id),
    CONSTRAINT fk_lead_services_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS lead_priorities (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    priority VARCHAR(255) NOT NULL DEFAULT 'NORMAL',
    INDEX idx_lprio_lead (lead_id),
    CONSTRAINT fk_lead_priorities_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS lead_references (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    url MEDIUMTEXT NOT NULL,
    INDEX idx_lref_lead (lead_id),
    CONSTRAINT fk_lead_references_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS lead_files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    original_name MEDIUMTEXT NOT NULL,
    stored_name MEDIUMTEXT NOT NULL,
    mime_type MEDIUMTEXT,
    size BIGINT,
    path TEXT NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_lfile_lead (lead_id),
    CONSTRAINT fk_lead_files_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS lead_notes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED NOT NULL,
    note MEDIUMTEXT NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_lnote_lead (lead_id),
    CONSTRAINT fk_lead_notes_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS clients (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lead_id BIGINT UNSIGNED UNIQUE,
    company MEDIUMTEXT,
    name MEDIUMTEXT NOT NULL,
    email VARCHAR(320) NOT NULL,
    whatsapp MEDIUMTEXT,
    phone MEDIUMTEXT,
    website MEDIUMTEXT,
    address MEDIUMTEXT,
    notes MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_clients_email (email),
    CONSTRAINT fk_clients_lead FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS client_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_id BIGINT UNSIGNED NOT NULL UNIQUE,
    email VARCHAR(320) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT fk_client_accounts_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS client_sessions (
    id CHAR(64) NOT NULL PRIMARY KEY,
    client_account_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    expires_at DATETIME(3) NOT NULL,
    CONSTRAINT fk_client_sessions_account FOREIGN KEY (client_account_id) REFERENCES client_accounts(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS mobile_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_account_id BIGINT UNSIGNED NOT NULL,
    access_token_hash CHAR(64) NOT NULL UNIQUE,
    refresh_token_hash CHAR(64) NOT NULL UNIQUE,
    access_expires_at DATETIME(3) NOT NULL,
    refresh_expires_at DATETIME(3) NOT NULL,
    device_name VARCHAR(80),
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    revoked_at DATETIME(3),
    INDEX idx_mobile_access (access_token_hash),
    INDEX idx_mobile_refresh (refresh_token_hash),
    CONSTRAINT fk_mobile_sessions_account FOREIGN KEY (client_account_id) REFERENCES client_accounts(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS projects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_id BIGINT UNSIGNED NOT NULL,
    name MEDIUMTEXT NOT NULL,
    description MEDIUMTEXT,
    budget MEDIUMTEXT,
    start_date MEDIUMTEXT,
    deadline MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'PLANNING',
    priority VARCHAR(255) NOT NULL DEFAULT 'NORMAL',
    progress INT NOT NULL DEFAULT 0 CHECK(progress >= 0 AND progress <= 100),
    technology_stack MEDIUMTEXT,
    repository_reference MEDIUMTEXT,
    deployment_information MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_projects_client (client_id),
    INDEX idx_projects_status (status),
    CONSTRAINT fk_projects_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS milestones (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT UNSIGNED NOT NULL,
    name MEDIUMTEXT NOT NULL,
    description MEDIUMTEXT,
    start_date MEDIUMTEXT,
    due_date MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'PLANNED',
    progress INT NOT NULL DEFAULT 0 CHECK(progress >= 0 AND progress <= 100),
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_milestones_project (project_id),
    CONSTRAINT fk_milestones_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS tasks (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT UNSIGNED NOT NULL,
    milestone_id BIGINT UNSIGNED,
    title MEDIUMTEXT NOT NULL,
    description MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'TODO',
    priority MEDIUMTEXT NOT NULL,
    due_date MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    INDEX idx_tasks_project (project_id),
    INDEX idx_tasks_milestone (milestone_id),
    CONSTRAINT fk_tasks_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT fk_tasks_milestone FOREIGN KEY (milestone_id) REFERENCES milestones(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS proposals (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_id BIGINT UNSIGNED NOT NULL,
    project_id BIGINT UNSIGNED,
    title MEDIUMTEXT NOT NULL,
    description MEDIUMTEXT,
    scope MEDIUMTEXT,
    deliverables MEDIUMTEXT,
    timeline MEDIUMTEXT,
    pricing MEDIUMTEXT,
    payment_schedule MEDIUMTEXT,
    terms MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',
    expires_at MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT fk_proposals_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    CONSTRAINT fk_proposals_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS invoices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_id BIGINT UNSIGNED NOT NULL,
    project_id BIGINT UNSIGNED,
    number VARCHAR(100) NOT NULL UNIQUE,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    subtotal DOUBLE NOT NULL DEFAULT 0,
    discount DOUBLE NOT NULL DEFAULT 0,
    tax DOUBLE NOT NULL DEFAULT 0,
    total DOUBLE NOT NULL DEFAULT 0,
    due_date MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT fk_invoices_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    CONSTRAINT fk_invoices_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS payments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT UNSIGNED NOT NULL,
    amount DOUBLE NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    provider MEDIUMTEXT,
    provider_reference MEDIUMTEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
    paid_at MEDIUMTEXT,
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    CONSTRAINT fk_payments_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
  `CREATE TABLE IF NOT EXISTS schema_migrations (
    id VARCHAR(100) NOT NULL PRIMARY KEY,
    applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
];

const seed = [
  `INSERT IGNORE INTO roles (name, description) VALUES
    ('SUPER_ADMIN', 'Full access to the 7Core administration platform'),
    ('ADMIN', 'Operational access to leads and client records'),
    ('SALES', 'Lead pipeline and communication access')`,
  `INSERT IGNORE INTO permissions (name, description) VALUES
    ('LEADS_VIEW', 'View lead records and lead statistics'),
    ('LEADS_EDIT', 'Update lead records and statuses'),
    ('LEADS_DELETE', 'Delete lead records'),
    ('LEADS_NOTES', 'Create internal lead notes'),
    ('LEADS_FILES_VIEW', 'Download lead files'),
    ('LEADS_FILES_MANAGE', 'Upload lead files'),
    ('ANALYTICS_VIEW', 'View dashboard analytics'),
    ('MANAGE_USERS', 'Create admins and manage roles')`,
  `INSERT IGNORE INTO permissions (name, description) VALUES
    ('CLIENTS_VIEW', 'View client records'),
    ('CLIENTS_MANAGE', 'Create and update client records'),
    ('PROJECTS_VIEW', 'View projects, milestones, and tasks'),
    ('PROJECTS_MANAGE', 'Create and update projects, milestones, and tasks'),
    ('BILLING_VIEW', 'View proposals and invoices'),
    ('BILLING_MANAGE', 'Manage proposals and invoices')`,
  `INSERT IGNORE INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.name = 'SUPER_ADMIN'`,
  `INSERT IGNORE INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r JOIN permissions p
    WHERE r.name = 'SALES' AND p.name IN
      ('LEADS_VIEW', 'LEADS_EDIT', 'LEADS_NOTES', 'LEADS_FILES_VIEW', 'ANALYTICS_VIEW')`,
  `INSERT IGNORE INTO admin_roles (admin_id, role_id)
    SELECT a.id, r.id FROM admins a CROSS JOIN roles r WHERE r.name = 'SUPER_ADMIN'`,
  `INSERT IGNORE INTO schema_migrations (id) VALUES ('001-rbac-foundation')`,
  `DELETE FROM role_permissions
    WHERE role_id = (SELECT id FROM roles WHERE name = 'ADMIN')
      AND NOT EXISTS (
        SELECT 1 FROM schema_migrations WHERE id = '002-admin-permission-scope'
      )`,
  `INSERT IGNORE INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r JOIN permissions p
    WHERE r.name = 'ADMIN'
      AND NOT EXISTS (
        SELECT 1 FROM schema_migrations WHERE id = '002-admin-permission-scope'
      )
      AND p.name IN (
        'LEADS_VIEW', 'LEADS_EDIT', 'LEADS_NOTES',
        'LEADS_FILES_VIEW', 'LEADS_FILES_MANAGE', 'ANALYTICS_VIEW'
      )`,
  `INSERT IGNORE INTO schema_migrations (id) VALUES ('002-admin-permission-scope')`,
  `DELETE FROM role_permissions
    WHERE role_id = (SELECT id FROM roles WHERE name = 'ADMIN')
      AND permission_id = (SELECT id FROM permissions WHERE name = 'MANAGE_USERS')
      AND NOT EXISTS (
        SELECT 1 FROM schema_migrations WHERE id = '003-remove-admin-user-management'
      )`,
  `INSERT IGNORE INTO schema_migrations (id) VALUES ('003-remove-admin-user-management')`,
  `INSERT IGNORE INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.name = 'SUPER_ADMIN'`,
  `INSERT IGNORE INTO role_permissions (role_id, permission_id)
    SELECT r.id, p.id FROM roles r JOIN permissions p
    WHERE r.name = 'ADMIN'
      AND NOT EXISTS (
        SELECT 1 FROM schema_migrations WHERE id = '004-client-project-commercial-foundation'
      )
      AND p.name IN (
        'CLIENTS_VIEW', 'CLIENTS_MANAGE', 'PROJECTS_VIEW',
        'PROJECTS_MANAGE', 'BILLING_VIEW'
      )`,
  `INSERT IGNORE INTO schema_migrations (id)
    VALUES ('004-client-project-commercial-foundation')`,
];

function getPool() {
  if (!pool) throw new Error("MySQL is not initialized. Call initDb() before querying.");
  return pool;
}

function normalizeDateTimeValue(value) {
  return typeof value === "string" && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z$/.test(value)
    ? value.replace("T", " ").replace(/Z$/, "")
    : value;
}

async function initDb({ seed = true } = {}) {
  if (pool) return;
  pool = mysql.createPool({
    host: process.env.MYSQL_HOST || "127.0.0.1",
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || "7core",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || "7core_solution",
    waitForConnections: true,
    connectionLimit: 10,
    supportBigNumbers: true,
    timezone: "Z",
  });
  pool.on("connection", (connection) => {
    connection.query("SET time_zone = '+00:00'", (err) => {
      if (!err) return;
      console.error("[7Core] Failed to set MySQL session time zone:", err);
      connection.destroy();
    });
  });

  try {
    for (const statement of schema) await pool.query(statement);
    if (seed) await seedDb();
  } catch (err) {
    await pool.end();
    pool = undefined;
    throw err;
  }
}

async function seedDb() {
  for (const statement of seed) await getPool().query(statement);
}

async function withTransaction(callback) {
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (err) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      err.rollbackError = rollbackError;
    }
    throw err;
  } finally {
    connection.release();
  }
}

async function run(sql, params = []) {
  const [result] = await getPool().execute(sql, params);
  return { lastInsertRowid: result.insertId, changes: result.affectedRows };
}

async function get(sql, params = []) {
  const [rows] = await getPool().execute(sql, params);
  return rows[0];
}

async function all(sql, params = []) {
  const [rows] = await getPool().execute(sql, params);
  return rows;
}

async function closeDb() {
  if (!pool) return;
  const activePool = pool;
  pool = undefined;
  await activePool.end();
}

module.exports = {
  initDb,
  seedDb,
  closeDb,
  run,
  get,
  all,
  schema,
  tableNames,
  normalizeDateTimeValue,
  withTransaction,
};
