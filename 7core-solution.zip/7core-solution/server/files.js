// server/files.js
// Validates and stores uploaded reference files. Files are written under
// UPLOAD_DIR, which sits outside /public and is never served directly —
// admin routes stream them back only after a session check (see routes.js).
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10MB per file
const ALLOWED_MIME = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/png",
  "image/jpeg",
  "image/webp",
]);
const ALLOWED_EXT = new Set([".pdf", ".doc", ".docx", ".png", ".jpg", ".jpeg", ".webp"]);

function safeExt(filename) {
  const ext = path.extname(filename || "").toLowerCase();
  return ALLOWED_EXT.has(ext) ? ext : null;
}

// Throws with .status/.message on rejection; otherwise returns file metadata
// and has already written the file to disk under a random, non-guessable name.
function storeUploadedFile(file, leadRef) {
  if (!file.buffer || file.buffer.length === 0) {
    throw Object.assign(new Error("Empty file"), { status: 400 });
  }
  if (file.buffer.length > MAX_FILE_BYTES) {
    throw Object.assign(new Error("This file exceeds the allowed size (10MB)."), { status: 413 });
  }
  const ext = safeExt(file.filename);
  if (!ext || (file.mimeType && !ALLOWED_MIME.has(file.mimeType))) {
    throw Object.assign(
      new Error("Unsupported file type. Allowed: PDF, DOC, DOCX, PNG, JPG, WEBP."),
      { status: 415 },
    );
  }
  const leadDir = path.join(UPLOAD_DIR, String(leadRef).replace(/[^a-zA-Z0-9_-]/g, ""));
  fs.mkdirSync(leadDir, { recursive: true });
  const storedName = `${crypto.randomBytes(16).toString("hex")}${ext}`;
  const fullPath = path.join(leadDir, storedName);

  // guard against path traversal even though storedName is generated, not user input
  if (!fullPath.startsWith(UPLOAD_DIR)) {
    throw Object.assign(new Error("Invalid file path"), { status: 400 });
  }
  fs.writeFileSync(fullPath, file.buffer);

  return {
    original_name: path.basename(file.filename).slice(0, 180),
    stored_name: storedName,
    mime_type: file.mimeType || null,
    size: file.buffer.length,
    path: path.relative(UPLOAD_DIR, fullPath),
  };
}

function resolveStoredFile(relPath) {
  const full = path.resolve(UPLOAD_DIR, relPath);
  if (!full.startsWith(UPLOAD_DIR)) return null; // path traversal guard
  if (!fs.existsSync(full)) return null;
  return full;
}

function removeLeadFiles(leadRef) {
  const safeRef = String(leadRef || "").replace(/[^a-zA-Z0-9_-]/g, "");
  if (!safeRef) return;
  const leadDir = path.resolve(UPLOAD_DIR, safeRef);
  if (!leadDir.startsWith(`${UPLOAD_DIR}${path.sep}`)) return;
  if (fs.existsSync(leadDir)) fs.rmSync(leadDir, { recursive: true, force: true });
}

module.exports = {
  UPLOAD_DIR,
  storeUploadedFile,
  resolveStoredFile,
  removeLeadFiles,
  MAX_FILE_BYTES,
};
